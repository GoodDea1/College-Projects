//============================================================================
// Name        : CS2_PointerPractice2.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

const int SIZE = 10;

void power2(double* dubPtr);
void zeroOut(double* dubArray);
int biggerByTen(double* &dubArray2);

int main() {

	double* doublePointer = nullptr;
	doublePointer = new double(567.23);

	double* doubleArray = nullptr;
	doubleArray = new double[SIZE];

	cout << "Old value: " << *doublePointer << endl;
	power2(doublePointer);
	cout << "New value: " << *doublePointer << endl << endl;

	for(unsigned int i=0; i<SIZE; i++){
		doubleArray[i] = i * 100;
		cout << "Address: " << &doubleArray[i] << endl;
		cout << "Value: " << doubleArray[i]    << endl << endl;
	}//for

	zeroOut(doubleArray);

	for(unsigned int i=0; i<SIZE; i++){
		doubleArray[i] = i * 100;
	}//for

	doubleArray = new double(biggerByTen(doubleArray));

//	doubleArray = new double(biggerByTen(doubleArray));

	delete doublePointer;
	doublePointer = nullptr;

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}

void power2(double* dubPtr){
	*dubPtr = *dubPtr * *dubPtr;
}//power2

void zeroOut(double* dubArray){
	for(unsigned int i=0; i<SIZE; i++){
		dubArray[i] = 0;
		cout << "Address: " << &dubArray[i] << endl;
		cout << "Value: " << dubArray[i] << endl << endl;
	}//for
}//zeroOut

int biggerByTen(double* &dubArray2){
	const int NEWSIZE = SIZE + 10;
	double* doubleArray2 = nullptr;
	doubleArray2 = new double[NEWSIZE];

	for(unsigned int i=0; i<NEWSIZE; i++){
		if(i<10){
			doubleArray2[i] = dubArray2[i];
		}//if
		else{
			doubleArray2[i] = 0;
		}//else
	}//for

	delete [] dubArray2;
	doubleArray2 = dubArray2;

	return NEWSIZE;
}//for
