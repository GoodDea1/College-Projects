//============================================================================
// Name        : CS2_Chapter_13_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "Animal.hpp"

int main() {

	vector<unique_ptr<Animal>> animalVector;
	vector<shared_ptr<Animal>> animalVectorShared;
	fstream file;
	string name;
	int populationCount;
	double supportCostPerMonth;


	file.open("AnimalFile.txt", ios::in);
	if(file.fail()){
		cout << "Error: Something went wrong while opening the file." << endl;
	}//if
	else{
		file.seekg(0L, ios::beg);
		while(!file.eof()) {
			unique_ptr<Animal> tempAnimal(new Animal);
			file >> name;
			file >> populationCount;
			file >> supportCostPerMonth;
			*tempAnimal = Animal(name, populationCount, supportCostPerMonth);
			animalVector.push_back(move(tempAnimal));
		}//while
		for(unsigned int i=0; i<animalVector.size(); i++) {
			animalVectorShared.push_back(move(animalVector[i]));
		}
		printAnimals(animalVectorShared);
	}//else

	file.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
