/*
 * Vegetable.cpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#include "Vegetable.hpp"

Vegetable::Vegetable() : Food() {
	// TODO Auto-generated constructor stub

}

int Vegetable::getTotalFiber() const {
	return totalFiber;
}

void Vegetable::setTotalFiber(int totalFiber) {
	this->totalFiber = totalFiber;
}

int Vegetable::getTotalSodium() const {
	return totalSodium;
}

void Vegetable::setTotalSodium(int totalSodium) {
	this->totalSodium = totalSodium;
}

string Vegetable::whoAmI(void) {
	return "Vegetable";
}

void Vegetable::print(void) {
	cout << setw(10) << whoAmI() << ":" << setw(20) << getName() << setw(10) << getTotalSodium() << endl;
}

Vegetable::~Vegetable() {
	// TODO Auto-generated destructor stub
}

