/*
 * Dairy.cpp
 *
 *  Created on: Apr 27, 2021
 *      Author: Nicholas Deal
 */

#include "Dairy.hpp"

Dairy::Dairy() : Food() {
	// TODO Auto-generated constructor stub
	//Food();		Can't use this since this can't create an object from an abstract class
}

double Dairy::getCholesterol() const {
	return cholesterol;
}

void Dairy::setCholesterol(double cholesterol) {
	this->cholesterol = cholesterol;
}

int Dairy::getFat() const {
	return fat;
}

void Dairy::setFat(int fat) {
	this->fat = fat;
}

Dairy::~Dairy() {
	// TODO Auto-generated destructor stub
}

string Dairy::whoAmI(void) {
	return "Dairy";
}

void Dairy::print(void) {
	cout << setw(10) << whoAmI() << ":" << setw(20) << getName() << setw(10) << getCholesterol() << setw(15) << getDatePurchased() << setw(15) << getExpireDate() << endl;
}
