/*
 * Food.cpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#include "Food.hpp"

Food::Food() {
	// TODO Auto-generated constructor stub

}

const string& Food::getDatePurchased() const {
	return datePurchased;
}

void Food::setDatePurchased(const string &datePurchased) {
	this->datePurchased = datePurchased;
}

const string& Food::getExpireDate() const {
	return expireDate;
}

void Food::setExpireDate(const string &expireDate) {
	this->expireDate = expireDate;
}

const string& Food::getName() const {
	return name;
}

void Food::setName(const string &name) {
	this->name = name;
}

string Food::whoAmI(void) {
	return "Food";
}

void Food::print(void) {
	cout << setw(10) << whoAmI() << ":" << setw(20) << getName() << setw(15) << getDatePurchased() << setw(15) << getExpireDate() << endl;
}

Food::~Food() {
	// TODO Auto-generated destructor stub
}

