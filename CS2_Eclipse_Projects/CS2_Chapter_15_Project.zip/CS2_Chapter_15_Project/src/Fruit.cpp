/*
 * Fruit.cpp
 *
 *  Created on: Apr 27, 2021
 *      Author: Nicholas Deal
 */

#include "Fruit.hpp"

Fruit::Fruit () : Food() {
	// TODO Auto-generated constructor stub
	//Food();		Can't use this since this can't create an object from an abstract class
}

long Fruit::getSugarAmount() const {
	return sugarAmount;
}

void Fruit::setSugarAmount(long sugarAmount) {
	this->sugarAmount = sugarAmount;
}

float Fruit::getTotalC() const {
	return totalC;
}

void Fruit::setTotalC(float totalC) {
	this->totalC = totalC;
}

Fruit::~Fruit() {
	// TODO Auto-generated destructor stub
}

string Fruit::whoAmI(void) {
	return "Fruit";
}

void Fruit::print(void) {
	cout << setw(10) << whoAmI() << ":" << setw(20) << getName() << setw(10) << getSugarAmount() << endl;
}
