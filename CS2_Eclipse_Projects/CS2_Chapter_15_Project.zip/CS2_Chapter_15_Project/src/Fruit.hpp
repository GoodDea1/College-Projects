/*
 * Fruit.hpp
 *
 *  Created on: Apr 27, 2021
 *      Author: Nicholas Deal
 */

#ifndef FRUIT_HPP_
#define FRUIT_HPP_

#include "Food.hpp"

class Fruit: public Food {
private:
	long sugarAmount;
	float totalC;
public:
	Fruit();
	virtual ~Fruit();
	long getSugarAmount() const;
	void setSugarAmount(long sugarAmount);
	float getTotalC() const;
	void setTotalC(float totalC);
	string whoAmI(void);
	void print(void);
};

#endif /* FRUIT_HPP_ */
