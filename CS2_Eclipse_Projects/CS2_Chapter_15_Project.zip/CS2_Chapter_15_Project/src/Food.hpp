/*
 * Food.hpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#ifndef FOOD_HPP_
#define FOOD_HPP_

#include <iostream>
#include <iomanip>
using namespace std;

class Food {
private:
	string name;
	string datePurchased;
	string expireDate;
public:
	Food();
	virtual ~Food();
	const string& getDatePurchased() const;
	void setDatePurchased(const string &datePurchased);
	const string& getExpireDate() const;
	void setExpireDate(const string &expireDate);
	const string& getName() const;
	void setName(const string &name);
	void virtual print(void) = 0;
	string virtual whoAmI(void) = 0;
};

#endif /* FOOD_HPP_ */
