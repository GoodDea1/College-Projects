/*
 * Date.hpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#ifndef DATE_HPP_
#define DATE_HPP_

#include <iostream>
using namespace std;

class Date {
private:
	int year;
	int month;
	int day;
public:
	Date();
	virtual ~Date();
	int getDay() const;
	void setDay(int day);
	int getMonth() const;
	void setMonth(int month);
	int getYear() const;
	void setYear(int year);
	string getDate(void);
};

#endif /* DATE_HPP_ */
