//============================================================================
// Name        : CS2_Chapter_15_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include "Date.hpp"
#include "Vegetable.hpp"
#include "Fruit.hpp"
#include "Dairy.hpp"
using namespace std;

int main() {

	fstream inputFile;
	string userInput;
	Food* myRefrigerator[100];
	Date date;
	string foodName;
	int foodType = 0;
	int fiber = 0;
	int sodium = 0;
	long sugar = 0;
	float vitC = 0.0;
	int fats = 0;
	double totalCholesterol = 0.0;
	int year = 0;
	int month = 0;
	int day = 0;
	int counter = 0;

	cout << "Welcome to the food reporting program" << endl;
	cout << "Please enter the file name: ";
	cin >> userInput;
	inputFile.open(userInput, ios::in);
	if (inputFile.fail()) {
		cout << "Something went wrong while opening the file." << endl;
	}//if
	else {
		while (!inputFile.eof()) {
			inputFile >> foodType;
			//Food
			//Can't use this since Food is an abstract class and therefore can't create any Food objects to store data into
//			if (foodType == 00) {
//				Food* foodPtr = nullptr;
//				//getting food name
//				inputFile >> foodName;
//				foodPtr->setName(foodName);
//				//getting purchase date
//				inputFile >> month >> day >> year;
//				date.setMonth(month);
//				date.setDay(day);
//				date.setYear(year);
//				foodPtr->setDatePurchased(date.getDate());
//				//getting expiration date
//				inputFile >> month >> day >> year;
//				date.setMonth(month);
//				date.setDay(day);
//				date.setYear(year);
//				foodPtr->setExpireDate(date.getDate());
//				myRefrigerator[counter] = foodPtr;
//				counter++;
//			}//if
			//Vegetables
			if (foodType == 01) {
				Vegetable* vegiePtr = new Vegetable();
				//getting vegie name
				inputFile >> foodName;
				vegiePtr->setName(foodName);
				//getting purchase date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				vegiePtr->setDatePurchased(date.getDate());
				//getting expiration date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				vegiePtr->setExpireDate(date.getDate());
				//getting total fiber
				inputFile >> fiber;
				vegiePtr->setTotalFiber(fiber);
				//getting total sodium
				inputFile >> sodium;
				vegiePtr->setTotalSodium(sodium);
				myRefrigerator[counter] = vegiePtr;
				counter++;
			}//else if
			//Fruits
			else if (foodType == 02) {
				Fruit* fruitPtr = new Fruit();
				//getting fruit name
				inputFile >> foodName;
				fruitPtr->setName(foodName);
				//getting purchase date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				fruitPtr->setDatePurchased(date.getDate());
				//getting expiration date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				fruitPtr->setExpireDate(date.getDate());
				//getting total sugar
				inputFile >> sugar;
				fruitPtr->setSugarAmount(sugar);
				//getting total vitamin C
				inputFile >> vitC;
				fruitPtr->setTotalC(vitC);
				myRefrigerator[counter] = fruitPtr;
				counter++;
			}//else if
			//Dairy
			else if (foodType == 03) {
				Dairy* dairyPtr = new Dairy();
				//getting dairy name
				inputFile >> foodName;
				dairyPtr->setName(foodName);
				//getting purchase date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				dairyPtr->setDatePurchased(date.getDate());
				//getting expiration date
				inputFile >> month >> day >> year;
				date.setMonth(month);
				date.setDay(day);
				date.setYear(year);
				dairyPtr->setExpireDate(date.getDate());
				//getting total fat
				inputFile >> fats;
				dairyPtr->setFat(fats);
				//getting total cholesterol
				inputFile >> totalCholesterol;
				dairyPtr->setCholesterol(totalCholesterol);
				myRefrigerator[counter] = dairyPtr;
				counter++;
			}//else if
			else {}
		}//while
		cout << endl;
		cout << "Food Report" << endl;
		cout << "===========" << endl;
		for (int i=0; i<counter; i++) {
			myRefrigerator[i]->print();
		}
		cout << endl;
	}//else

	delete [] myRefrigerator;

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
