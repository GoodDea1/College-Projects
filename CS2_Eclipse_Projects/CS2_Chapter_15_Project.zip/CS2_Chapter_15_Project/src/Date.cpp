/*
 * Date.cpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#include "Date.hpp"

Date::Date() {
	// TODO Auto-generated constructor stub

}

int Date::getDay() const {
	return day;
}

void Date::setDay(int day) {
	this->day = day;
}

int Date::getMonth() const {
	return month;
}

void Date::setMonth(int month) {
	this->month = month;
}

int Date::getYear() const {
	return year;
}

void Date::setYear(int year) {
	this->year = year;
}

string Date::getDate(void) {
	string theDate = to_string(getMonth()) + "/" + to_string(getDay()) + "/" + to_string(getYear());
	return theDate;
}

Date::~Date() {
	// TODO Auto-generated destructor stub
}

