/*
 * Vegetable.hpp
 *
 *  Created on: Apr 22, 2021
 *      Author: Nicholas Deal
 */

#ifndef VEGETABLE_HPP_
#define VEGETABLE_HPP_

#include "Food.hpp"

class Vegetable: public Food {
private:
	int totalFiber;
	int totalSodium;
public:
	Vegetable();
	virtual ~Vegetable();
	int getTotalFiber() const;
	void setTotalFiber(int totalFiber);
	int getTotalSodium() const;
	void setTotalSodium(int totalSodium);
	string whoAmI(void);
	void print(void);
};

#endif /* VEGETABLE_HPP_ */
