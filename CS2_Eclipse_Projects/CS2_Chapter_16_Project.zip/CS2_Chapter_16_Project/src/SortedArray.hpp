/*
 * SortedArray.hpp
 *
 *  Created on: May 6, 2021
 *      Author: Nicholas Deal
 */

#ifndef SORTEDARRAY_HPP_
#define SORTEDARRAY_HPP_

#include <iostream>
using namespace std;

class ErrorClass {
public:
	ErrorClass(){}
	virtual ~ErrorClass(){}
	string Message = "ERROR: The amount of items in the array exceed the total amount of space, can't add anymore items.";
	int ErrorCode = 123;
};

template <class T>
class SortedArray {
private:
	T* arrayPtr;
	int arraySize;
	int totalItems;
public:
	bool arraySorted;

	void SetSorted(bool trueOrFalse) {
		if (trueOrFalse == true) {
			this->setArraySorted(true);
		}//if
		else{
			this->setArraySorted(false);
		}
	}

	SortedArray(){}
	SortedArray(int arraySize, bool tf) {
		this->setArraySize(arraySize);
		this->setTotalItems(0);
		this->arrayPtr = new T[this->getArraySize()];
		SetSorted(tf);
	}

	void swap(T &x, T &y) {
		T tempValue = x;
		x = y;
		y = tempValue;
	}//swap

	void SortArray(void) {
		for(int i=0; i<this->getTotalItems()-1; i++) {
			for(int j=i+1; j<this->getTotalItems(); j++) {
				if (this->arrayPtr[i] > this->arrayPtr[j]) {
					swap(this->arrayPtr[i], this->arrayPtr[j]);
				}//if
				else{}
			}//for
		}//for
	}//SortArray

	void AddEnd(T something) {
		if (this->getTotalItems() == this->getArraySize()) {
			ErrorClass* error = new ErrorClass();
			throw error;
		}//if
		else {
			this->arrayPtr[this->getTotalItems()] = something;
			this->setTotalItems(this->getTotalItems()+1);

			if (this->isArraySorted() == true) {
				SortArray();
			}//if
			else {}
		}//else
	}

	void AddBegin(T something2) {
		if (this->getTotalItems() == this->getArraySize()) {
			ErrorClass* error2 = new ErrorClass();
			throw error2;
		}//if
		else {
			if (this->getTotalItems() == 0 ) {
				this->arrayPtr[0] = something2;
				this->setTotalItems(this->getTotalItems()+1);
			}//if
			else {
				for (int i=(this->getTotalItems()-1); i>=0; i--) {
					this->arrayPtr[i+1] = this->arrayPtr[i];
				}//for
				this->arrayPtr[0] = something2;
				this->setTotalItems(this->getTotalItems()+1);
			}//else
			if (this->isArraySorted() == true) {
				SortArray();
			}//if
			else {}
		}//else
	}

	void PrintArray(void) {
		for (int i=0; i<this->getTotalItems(); i++) {
			cout << this->arrayPtr[i] << endl;
		}//for
	}

	virtual ~SortedArray(){}

	int getArraySize(void) const {
		return arraySize;
	}

	void setArraySize(int arraySize) {
		this->arraySize = arraySize;
	}

	int getTotalItems(void) const {
		return totalItems;
	}

	void setTotalItems(int totalItems) {
		this->totalItems = totalItems;
	}

	bool isArraySorted() const {
		return arraySorted;
	}

	void setArraySorted(bool arraySorted) {
		this->arraySorted = arraySorted;
	}
};

#endif /* SORTEDARRAY_HPP_ */
