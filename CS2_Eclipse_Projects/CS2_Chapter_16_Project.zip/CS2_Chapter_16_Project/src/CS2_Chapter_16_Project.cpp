//============================================================================
// Name        : CS2_Chapter_16_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "SortedArray.hpp"
using namespace std;

int main() {

	cout << "Testing arrays..." << endl << endl;
	SortedArray<int> intArray(5, true);
	try {
		cout << "Integer Array:" << endl;
		intArray.AddBegin(1);
		intArray.AddBegin(2);
		intArray.AddBegin(3);
		intArray.AddBegin(4);
		intArray.AddBegin(5);
		intArray.PrintArray();
		cout << endl;
	}
	catch (ErrorClass* e) {
		cout << e->Message << endl;
		cout << "Error code: " << e->ErrorCode << endl << endl;
	}

	SortedArray<double> doubleArray(5, false);
	try {
		cout << "Double Array:" << endl;
		doubleArray.AddEnd(1.1);
		doubleArray.AddEnd(2.2);
		doubleArray.AddEnd(3.3);
		doubleArray.AddEnd(4.4);
		doubleArray.AddEnd(5.5);
		doubleArray.PrintArray();
		cout << endl;
	}
	catch (ErrorClass* e) {
		cout << e->Message << endl;
		cout << "Error code: " << e->ErrorCode << endl << endl;
	}

	SortedArray<string> stringArray(5, true);
	try {
		cout << "String Array:" << endl;
		stringArray.AddBegin("aaa");
		stringArray.AddBegin("bbb");
		stringArray.AddBegin("ccc");
		stringArray.AddBegin("ddd");
		stringArray.AddBegin("eee");
		stringArray.PrintArray();
		cout << endl;
	}
	catch (ErrorClass* e) {
		cout << e->Message << endl;
		cout << "Error code: " << e->ErrorCode << endl << endl;
	}

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
