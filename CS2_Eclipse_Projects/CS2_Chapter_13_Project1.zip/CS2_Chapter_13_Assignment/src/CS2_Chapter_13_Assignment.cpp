//============================================================================
// Name        : CS2_Chapter_13_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "Animal.hpp"

int main() {

	vector<Animal*> animalVector;
	fstream file;
	string name;
	int populationCount;
	double supportCostPerMonth;


	file.open("AnimalFile.txt", ios::in);
	if(file.fail()){
		cout << "Error: Something went wrong while opening the file." << endl;
	}//if
	else{
		file.seekg(0L, ios::beg);
		while(!file.eof()) {
			Animal* tempAnimal = new Animal();
			file >> name;
			file >> populationCount;
			file >> supportCostPerMonth;
			*tempAnimal = Animal(name, populationCount, supportCostPerMonth);
			animalVector.push_back(tempAnimal);
		}//while
	}//else

	printAnimals(animalVector);
	deletePointers(animalVector);

	file.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
