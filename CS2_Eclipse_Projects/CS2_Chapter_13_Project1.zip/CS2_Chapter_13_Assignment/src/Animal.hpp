/*
 * Animal.hpp
 *
 *  Created on: Mar 2, 2021
 *      Author: Nicholas Deal
 */

#ifndef ANIMAL_HPP_
#define ANIMAL_HPP_

#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
using namespace std;

class Animal {
private:
	string name;
	int populationCount;
	double supportCostPerMonth;

public:
	Animal();
	Animal(string theName);
	Animal(string theName, int thePopulation, double theSupportCost);
	virtual ~Animal();
	const string& getName() const;
	bool setName(const string &name);
	int getPopulationCount() const;
	bool setPopulationCount(int populationCount);
	double getSupportCostPerMonth() const;
	bool setSupportCostPerMonth(double supportCostPerMonth);
};

void printAnimals(vector<Animal*> animalPtrVector);
void deletePointers(vector<Animal*> animalPtrVector);

#endif /* ANIMAL_HPP_ */
