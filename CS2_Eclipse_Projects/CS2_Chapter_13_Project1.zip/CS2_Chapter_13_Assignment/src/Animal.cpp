/*
 * Animal.cpp
 *
 *  Created on: Mar 2, 2021
 *      Author: Nicholas Deal
 */

#include "Animal.hpp"

Animal::Animal() {
	// TODO Auto-generated constructor stub
	this->name = "";
	this->populationCount = 0;
	this->supportCostPerMonth = 0.0;
}

Animal::Animal(string theName){
	this->name = theName;
	this->populationCount = 0;
	this->supportCostPerMonth = 0.0;
}

Animal::Animal(string theName, int thePopulation, double theSupportCost){
	if (setName(theName)){
		this->name = theName;
	}//if
	else{
		cout << "Error: Name is missing" << endl;
	}//else

	if (setPopulationCount(thePopulation)){
		this->populationCount = thePopulation;
	}//if
	else{
		cout << "Error: The population must be greater than zero" << endl;
	}//else

	if (setSupportCostPerMonth(theSupportCost)){
		this->supportCostPerMonth = theSupportCost;
	}//if
	else{
		cout << "Error: The support cost must be greater than zero" << endl;
	}//else
}

const string& Animal::getName() const {
	return name;
}

bool Animal::setName(const string &name) {
	if (name == ""){
		return false;
	}//if
	else{
		return true;
	}//else
}

int Animal::getPopulationCount() const {
	return populationCount;
}

bool Animal::setPopulationCount(int populationCount) {
	if(populationCount <= 0){
		return false;
	}//if
	else{
		return true;
	}//else
}

double Animal::getSupportCostPerMonth() const {
	return supportCostPerMonth;
}

bool Animal::setSupportCostPerMonth(double supportCostPerMonth) {
	if(supportCostPerMonth <= 0){
		return false;
	}//if
	else{
		return true;
	}//else
}

Animal::~Animal() {
	// TODO Auto-generated destructor stub
}

void printAnimals(vector<Animal*> animalPtrVector){
	double totalMonthly = 0.0;
	cout << "Animal Population Report" << endl;
	cout << "========================" << endl;
	cout << setw(20) << "Animal Species" << setw(11) << "Count" << setw(15) << "Cost" << endl;
	cout << setw(20) << "--------------" << setw(11) << "-----" << setw(15) << "----" << endl;
	cout << fixed << setprecision(2);
	for(unsigned int i=0; i<animalPtrVector.size(); i++){
		cout << setw(20) << animalPtrVector[i]->getName() << setw(11) << animalPtrVector[i]->getPopulationCount() << setw(15) << animalPtrVector[i]->getSupportCostPerMonth() << endl;
		totalMonthly += animalPtrVector[i]->getPopulationCount() * animalPtrVector[i]->getSupportCostPerMonth();
	}//for
	cout << endl << "Total monthly cost: " << totalMonthly << endl;
	cout << "Total yearly cost: " << totalMonthly * 12 << endl << endl;
}//printAnimals

void deletePointers(vector<Animal*> animalPtrVector){
	for(unsigned int i=0; i<animalPtrVector.size(); i++){
		delete animalPtrVector[i];
		animalPtrVector[i] = nullptr;
	}//for
}//deletePointers
