/*
 * Animal.cpp
 *
 *  Created on: Feb 21, 2021
 *      Author: Nicholas Deal
 */
#include "Animal.hpp"

void printAnimals(vector<animal*> animalPtrVector){
	double totalMonthly = 0.0;
	cout << "Animal Population Report" << endl;
	cout << "========================" << endl;
	cout << setw(20) << "Animal Species" << setw(11) << "Count" << setw(15) << "Cost" << endl;
	cout << setw(20) << "--------------" << setw(11) << "-----" << setw(15) << "----" << endl;
	cout << fixed << setprecision(2);
	for(unsigned int i=0; i<animalPtrVector.size(); i++){
		cout << setw(20) << animalPtrVector[i]->name << setw(11) << animalPtrVector[i]->populationCount << setw(15) << animalPtrVector[i]->supportCostPerMonth << endl;
		totalMonthly += animalPtrVector[i]->supportCostPerMonth;
	}//for
	cout << "Total monthly cost: " << totalMonthly << endl;
	cout << "Total yearly cost: " << totalMonthly * 12 << endl;
}//printAnimals

void deletePointers(vector<animal*> animalPtrVector){
	for(unsigned int i=0; i<animalPtrVector.size(); i++){
		delete animalPtrVector[i];
	}//for
}//deletePointers
