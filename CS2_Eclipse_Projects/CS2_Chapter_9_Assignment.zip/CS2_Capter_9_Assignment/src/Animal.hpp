/*
 * Animal.hpp
 *
 *  Created on: Feb 21, 2021
 *      Author: Nicholas Deal
 */

#ifndef ANIMAL_HPP_
#define ANIMAL_HPP_

#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
using namespace std;

struct animal{
	char name[32];
	int populationCount;
	double supportCostPerMonth;
};

void printAnimals(vector<animal*> animalPtrVector);
void deletePointers(vector<animal*> animalPtrVector);

#endif /* ANIMAL_HPP_ */
