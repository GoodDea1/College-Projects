//============================================================================
// Name        : CS2_Capter_9_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "Animal.hpp"

int main() {

	vector<animal*> Animal;
	fstream file;

	file.open("AnimalFile.txt", ios::in);
	if(file.fail()){
		cout << "Error: Something went wrong while opening the file." << endl;
	}//if
	else{
		file.seekg(0L, ios::beg);
		while(!file.eof()) {
			animal* tempAnimal = new animal();
			file >> tempAnimal->name;
			file >> tempAnimal->populationCount;
			file >> tempAnimal->supportCostPerMonth;
			Animal.push_back(tempAnimal);
		}//while
	}//else

	printAnimals(Animal);
	deletePointers(Animal);

	file.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
