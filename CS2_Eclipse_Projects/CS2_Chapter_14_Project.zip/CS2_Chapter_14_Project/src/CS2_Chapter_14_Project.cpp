//============================================================================
// Name        : CS2_Chapter_14_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Date.hpp"
using namespace std;

int main() {

//	Date todaysDate;
//	todaysDate.setYear(2021);
//	todaysDate.setMonth(1);
//	todaysDate.setDay(1);
//
//	cout << "Totay's date is: " << todaysDate << endl;
//	todaysDate++;
//	cout << "Today's date after increment is: " << todaysDate << endl;
//	todaysDate--;
//	cout << "Today's date after the decrement is: " << todaysDate << endl;
//
//	for (int i = 0; i<365; i++) {
//		todaysDate++;
//		cout << "Today's date after increment is: " << todaysDate << endl;
//	}
//
//	Date testDate;
//	testDate.setYear(2022);
//	testDate.setMonth(1);
//	testDate.setDay(1);
//
//	if (todaysDate < testDate) {
//		cout << "Today is less than test." << endl;
//	}//if
//	else if (todaysDate > testDate) {
//		cout << "Today is greater than test." << endl;
//	}//else if
//	else if (todaysDate == testDate) {
//		cout << "The two dates are equal." << endl;
//	}//else if
//	else {
//		cout << "Something screwed up, check the code again." << endl;
//	}//else

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
