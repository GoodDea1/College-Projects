/*
 * Date.hpp
 *
 *  Created on: Apr 4, 2021
 *      Author: Nicholas Deal
 */

#ifndef DATE_HPP_
#define DATE_HPP_

#include <iostream>
using namespace std;

class Date {
private:
	int day;
	int month;
	int year;
public:
	Date();
	virtual ~Date();
	int getDay() const;
	bool setDay(int day);
	int getMonth() const;
	bool setMonth(int month);
	int getYear() const;
	bool setYear(int year);
	bool operator++(int);
	bool operator--(int);
	bool operator==(const Date &rval);
	friend ostream &operator<<(ostream &lval, const Date &rval);
	bool operator<(const Date &rval);
	bool operator>(const Date &rval);
};

#endif /* DATE_HPP_ */
