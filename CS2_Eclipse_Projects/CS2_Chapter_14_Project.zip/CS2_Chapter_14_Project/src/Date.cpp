/*
 * Date.cpp
 *
 *  Created on: Apr 4, 2021
 *      Author: Nicholas Deal
 */

#include "Date.hpp"

Date::Date() {
	// TODO Auto-generated constructor stub
	this->day = 0;
	this->month = 0;
	this->year = 0;
}

int Date::getDay() const {
	return day;
}

bool Date::setDay(int day) {
	if (this->year != 0) {
		if (day >= 1) {
			//January
			if (this->month == 1) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days January has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//February
			else if (this->month == 2) {
				if (day > 28) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days February has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//March
			else if (this->month == 3) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days March has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//April
			else if (this->month == 4) {
				if (day > 30) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days April has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//May
			else if (this->month == 5) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days May has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//June
			else if (this->month == 6) {
				if (day > 30) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days June has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//July
			else if (this->month == 7) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days July has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//August
			else if (this->month == 8) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days August has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//September
			else if (this->month == 9) {
				if (day > 30) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days September has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//October
			else if (this->month == 10) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days October has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//November
			else if (this->month == 11) {
				if (day > 30) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days November has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			//December
			else if (this->month == 12) {
				if (day > 31) {
					cout << "Sorry, it looks like the number of days entered goes over the number of days December has." << endl;
					return false;
				}//if
				else {
					this->day = day;
					return true;
				}//else
			}//else if
			else {
				cout << "It looks like you haven't entered a month yet, therefore a day can't be entered." << endl;
				return false;
			}//else
		}//if
		else {
			cout << "The number of days needs to be at least greater than 1." << endl;
			return false;
		}//else
	}//if
	else {
		cout << "It looks like  you haven't entered a year yet, therefore a day can't be entered." << endl;
		return false;
	}//else
}

int Date::getMonth() const {
	return month;
}

bool Date::setMonth(int month) {
	if (month < 1 or month > 12) {
		cout << "The number for the month isn't within 1 or 12." << endl;
		return false;
	}//if
	else {
		this->month = month;
		return true;
	}//else
}

int Date::getYear() const {
	return year;
}

bool Date::setYear(int year) {
	if (year < 1 or year > 9999) {
		cout << "The number for the year needs to be within 1 and 9999." << endl;
		return false;
	}//if
	else {
		this->year = year;
		return true;
	}//else
}

bool Date::operator++(int) {
	if (this->year != 0 and this->month != 0 and this->day != 0) {
		//January
		if (this->month == 1) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//February
		else if (this->month == 2) {
			if (this->day == 28) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//March
		else if (this->month == 3) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//April
		else if (this->month == 4) {
			if (this->day == 30) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//May
		else if (this->month == 5) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//June
		else if (this->month == 6) {
			if (this->day == 30) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//July
		else if (this->month == 7) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//August
		else if (this->month == 8) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//September
		else if (this->month == 9) {
			if (this->day == 30) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//October
		else if (this->month == 10) {
			if (this->day == 31) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//November
		else if (this->month == 11) {
			if (this->day == 30) {
				this->month++;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		//December
		else if (this->month == 12) {
			if (this->day == 31) {
				this->year++;
				this->month = 1;
				this->day = 1;
				return true;
			}//if
			else {
				this->day++;
				return true;
			}//else
		}//if
		else {
			return false;
		}//else
	}//if
	else {
		return false;
	}//else
}

bool Date::operator--(int) {
	if (this->year != 0 and this->month != 0 and this->day != 0) {
		//January
		if (this->month == 1) {
			if (this->day == 1) {
				this->year--;
				this->month = 12;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//February
		else if (this->month == 2) {
			if (this->day == 1) {
				this->month--;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//March
		else if (this->month == 3) {
			if (this->day == 1) {
				this->month--;
				this->day = 28;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//April
		else if (this->month == 4) {
			if (this->day == 1) {
				this->month++;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//May
		else if (this->month == 5) {
			if (this->day == 1) {
				this->month--;
				this->day = 30;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//June
		else if (this->month == 6) {
			if (this->day == 1) {
				this->month--;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//July
		else if (this->month == 7) {
			if (this->day == 1) {
				this->month--;
				this->day = 30;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//August
		else if (this->month == 8) {
			if (this->day == 1) {
				this->month--;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//September
		else if (this->month == 9) {
			if (this->day == 1) {
				this->month--;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//October
		else if (this->month == 10) {
			if (this->day == 1) {
				this->month--;
				this->day = 30;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//November
		else if (this->month == 11) {
			if (this->day == 1) {
				this->month--;
				this->day = 31;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		//December
		else if (this->month == 12) {
			if (this->day == 1) {
				this->month--;
				this->day = 30;
				return true;
			}//if
			else {
				this->day--;
				return true;
			}//else
		}//if
		else {
			return false;
		}//else
	}//if
	else {
		return false;
	}//else
}

bool Date::operator==(const Date &rval) {
	if (this->year == rval.year) {
		if (this->month == rval.month) {
			if (this->day == rval.day) {
				return true;
			}//if
			else {
				return false;
			}//else
		}//if
		else {
			return false;
		}//else
	}//if
	else {
		return false;
	}//else
}

ostream &operator<<(ostream &lval, const Date &rval) {
	if (rval.day == 0 or rval.month == 0 or rval.year == 0) {
		lval << "Sorry, can't output invalid dates.";
	}//if
	else {
		if (rval.month < 10) {
			if (rval.day < 10) {
				if (rval.year < 1000) {
					if (rval.year < 100) {
						if (rval.year < 10) {
							lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "000" << rval.year;
						}//if
						else {
							lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "00" << rval.year;
						}//else
					}//if
					else {
						lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "0" << rval.year;
					}//else
				}//if
				else {
					lval << "0" << rval.month << "/" << "0" << rval.day << "/" << rval.year;
				}//else
			}//if
			else {
				lval << "0" << rval.month << "/" << rval.day << "/" << rval.year;
			}//else
		}//if
		else if (rval.day < 10) {
			if (rval.month < 10) {
				if (rval.year < 1000) {
					if (rval.year < 100) {
						if (rval.year < 10) {
							lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "000" << rval.year;
						}//if
						else {
							lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "00" << rval.year;
						}//else
					}//if
					else {
						lval << "0" << rval.month << "/" << "0" << rval.day << "/" << "0" << rval.year;
					}//else
				}//if
				else {
					lval << "0" << rval.month << "/" << "0" << rval.day << "/" << rval.year;
				}//else
			}//if
			else {
				lval << rval.month << "/" << "0" << rval.day << "/" << rval.year;
			}//else
		}//if
		else {
			lval << rval.month << "/" << rval.day << "/" << rval.year;
		}//else
	}//else
	return lval;
}

bool Date::operator<(const Date &rval) {
	if (this->year < rval.year) {
		return true;
	}//if
	else if (this->year == rval.year) {
		if (this->month < rval.month) {
			return true;
		}//if
		else if (this->month == rval.month) {
			if (this->day < rval.day) {
				return true;
			}//if
			else {
				return false;
			}//else
		}//else if
		else {
			return false;
		}//else
	}//else if
	else {
		return false;
	}//else
}

bool Date::operator>(const Date &rval) {
	if (this->year > rval.year) {
		return true;
	}//if
	else if (this->year == rval.year) {
		if (this->month > rval.month) {
			return true;
		}//if
		else if (this->month == rval.month) {
			if (this->day > rval.day) {
				return true;
			}//if
			else {
				return false;
			}//else
		}//else if
		else {
			return false;
		}//else
	}//else if
	else {
		return false;
	}//else
}

Date::~Date() {
	// TODO Auto-generated destructor stub
}

