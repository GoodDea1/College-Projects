//============================================================================
// Name        : CS2_PointerPractice_1.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
using namespace std;

struct TVShow{
	int YearBegan;
	char Name[32];
	int NumberOfEpisodes;
};

int main() {

//Exercise #1
	double* doublePointer = new double(0);
	*doublePointer = 123.45;

	cout << doublePointer << endl;
	cout << *doublePointer << endl;

	delete doublePointer;

//Exercise #2
	TVShow* showInfo;
	showInfo = new TVShow;
	strcpy(showInfo->Name, "JoJo's Bizarre Adventure");
	showInfo->NumberOfEpisodes = 151;
	showInfo->YearBegan = 2012;
	cout << "Name: " << showInfo->Name << endl;
	cout << "Number of episodes: " << showInfo->NumberOfEpisodes << endl;
	cout << "Released: " << showInfo->YearBegan << endl;

	delete showInfo;

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
