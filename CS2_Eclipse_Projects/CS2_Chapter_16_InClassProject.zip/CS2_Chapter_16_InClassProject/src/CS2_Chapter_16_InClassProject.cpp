//============================================================================
// Name        : CS2_Chapter_16_InClassProject.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "functions.hpp"
using namespace std;

int ARRAYSIZE = 5;

int main() {

	int intArray[ARRAYSIZE];
	double doubleArray[ARRAYSIZE];

	cout << Minimum(10, 20) << endl;
	cout << Minimum(10.5, 20.6) << endl;
	cout << Maximum(15, 25) << endl;
	cout << Maximum(12.5, 27.6) << endl;

	intArray[0] = 1;
	intArray[1] = 2;
	intArray[2] = 3;
	intArray[3] = 4;
	intArray[4] = 5;

	doubleArray[0] = 1.1;
	doubleArray[1] = 2.2;
	doubleArray[2] = 3.3;
	doubleArray[3] = 4.4;
	doubleArray[4] = 5.5;

	TestScores<int> intScoreSheet(intArray, ARRAYSIZE);
	cout << intScoreSheet.getAverage() << endl;

	TestScores<double> doubleScoreSheet(doubleArray, ARRAYSIZE);
	cout << doubleScoreSheet.getAverage() << endl;

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}

