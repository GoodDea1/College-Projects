/*
 * functions.hpp
 *
 *  Created on: Apr 29, 2021
 *      Author: Nicholas Deal
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_

template <class T>
class TestScores {
public:
	T* scores;
	int size;
	TestScores() {}
	TestScores(T* array, int arraySize) {
		this->scores = array;
		this->size = arraySize;
	}
	virtual ~TestScores() {}
	double getAverage() {
		double total = 0;
		for (int i=0; i<size; i++) {
			if (*scores < 0 || *scores > 100) {
				throw "Test scores are invalid";
				break;
			}//if
			else {
				total += scores[i];
			}//else
		}//for
		return total/size;
	}//getAverage
};


template <class T>
T Minimum (T val1, T val2) {
	if (val1 <= val2) {
		return val1;
	}//if
	else {
		return val2;
	}//else
}

template <class T>
T Maximum (T val3, T val4) {
	if (val3 >= val4) {
		return val3;
	}//if
	else {
		return val4;
	}//else
}

#endif /* FUNCTIONS_HPP_ */
