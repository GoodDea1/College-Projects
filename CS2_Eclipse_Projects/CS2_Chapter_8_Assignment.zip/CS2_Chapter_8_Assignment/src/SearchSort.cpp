/*
 * SearchSort.cpp
 *
 *  Created on: Feb 3, 2021
 *      Author: Nicholas Deal
 */
#include <iostream>
#include <vector>
#include "SearchSort.hpp"
using namespace std;

void bubbleSort(vector<int> &intVector, char ascendDescend){
	bool swapped = true;
	if(ascendDescend == 'D' || ascendDescend == 'd'){
		while(swapped == true) {
			swapped = false;
			for(unsigned int i=0; i<intVector.size()-1; i++) {
				if (intVector[i] < intVector[i+1]) {
					swap(intVector[i], intVector[i+1]);
					swapped = true;
				}//if
				else{}
			}//for
		}//while
	}//if
	else if(ascendDescend == 'A' || ascendDescend == 'a'){
		while(swapped == true) {
			swapped = false;
			for(unsigned int i=0; i<intVector.size()-1; i++) {
				if (intVector[i] > intVector[i+1]) {
					swap(intVector[i], intVector[i+1]);
					swapped = true;
				}//if
				else{}
			}//for
		}//while
	}//else if
	else{}
}//bubbleSort

void selectSort(vector<int> &intVector, char ascendDescend){
	if(ascendDescend == 'D' || ascendDescend == 'd'){
		for(unsigned int i=0; i<intVector.size()-1; i++) {
			for(unsigned int j=i+1; j<intVector.size(); j++) {
				if (intVector[i] < intVector[j]) {
					swap(intVector[i], intVector[j]);
				}//if
				else{}
			}//for
		}//for
	}//if
	else if(ascendDescend == 'A' || ascendDescend == 'a'){
		for(unsigned int i=0; i<intVector.size()-1; i++) {
			for(unsigned int j=i+1; j<intVector.size(); j++) {
				if (intVector[i] > intVector[j]) {
					swap(intVector[i], intVector[j]);
				}//if
				else{}
			}//for
		}//for
	}//else if
	else{}
}//selectSort

bool intLinearSearch(vector<int> &intVector, int search){
	bool found = false;
	for(unsigned int i=0; i<intVector.size()-1; i++){
		if(search == intVector[i]){
			found = true;
			break;
		}//if
		else{}
	}//for
	return found;
}//intLinearSearch

bool intBinSearch(vector<int> &intVector, int search){
	bool found = false;
	int first = 0;
	int last = intVector.size() - 1;
	int middle;
	while(!found && first <= last){
		middle = ((first + last)/2) + first;
		if(intVector[middle] == search){
			found = true;
		}//if
		else if (intVector[middle] > search){
			last = middle - 1;
		}//else if
		else{
			first = middle + 1;
		}//else
	}//while
	return found;
}//intBinSearch
