/*
 * SearchSort.hpp
 *
 *  Created on: Feb 3, 2021
 *      Author: Nicholas Deal
 */

#ifndef SEARCHSORT_HPP_
#define SEARCHSORT_HPP_
using namespace std;

void bubbleSort(vector<int>&, char);
void selectSort(vector<int>&, char);
bool intLinearSearch(vector<int>&, int);
bool intBinSearch(vector<int> &, int);


#endif /* SEARCHSORT_HPP_ */
