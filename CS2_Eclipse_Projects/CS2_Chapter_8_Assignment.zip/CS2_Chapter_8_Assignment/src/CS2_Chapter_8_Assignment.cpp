//============================================================================
// Name        : CS2_Chapter_8_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <ctime>
#include <vector>
#include <climits>
#include "SearchSort.hpp"
using namespace std;

const int ARRAYSIZE = 10;

int main() {

	vector<int> intVector;
	char userInput;

	do{
		cout << "Welcome to my Sort/Search App" << endl;
		cout << "=============================" << endl;
		cout << "1. Generate Random Data" << endl;
		cout << "2. Bubble Sort the Vector" << endl;
		cout << "3. Select Sort the Vector" << endl;
		cout << "4. Binary Search the Vector" << endl;
		cout << "5. Linear Search the Vecotr" << endl;
		cout << "6. Print out the Vector" << endl;
		cout << "x. Exit the program" << endl;
		cout << "Please enter a menu option: ";
		cin >> userInput;
		switch(userInput){
		case '1':
			srand(time(0));
			for (int i=0; i<ARRAYSIZE; i++) {
				intVector.push_back(rand()%10);
			}//for
			break;
		case '2':
			char ascendDescent;
			cout << endl << "Would you like the list ordered by ascending or descending numbers(type A or D): ";
			cin >> ascendDescent;
			if(ascendDescent == 'a' || ascendDescent == 'A' || ascendDescent == 'd' || ascendDescent == 'D'){
				bubbleSort(intVector, ascendDescent);
			}//if
			else{
				cout << "Input is not valid" << endl;
			}//else
			break;
		case '3':
			char ascendDescent2;
			cout << endl << "Would you like the list ordered by ascending or descending numbers(type A or D): ";
			cin >> ascendDescent2;
			if(ascendDescent2 == 'a' || ascendDescent2 == 'A' || ascendDescent2 == 'd' || ascendDescent2 == 'D'){
				selectSort(intVector, ascendDescent2);
			}//if
			else{
				cout << "Input is not valid" << endl;
			}//else
			break;
		case '4':
			{
				int searchInput = 0;
				bool numberSearched;
				cout << endl << "Warning: It is recommended that the numbers are sorted in ascending order." << endl;
				cout << "Please enter the number you wish to search: ";
				cin >> searchInput;
				cin.clear();
				cin.ignore(INT_MAX, '\n');
				numberSearched = intBinSearch(intVector, searchInput);
				if(numberSearched == true){
					cout << "The number " << searchInput << " is on this list." << endl;
				}//if
				else{
					cout << "The number " << searchInput << " is not on this list." << endl;
				}//else
				break;
			}
		case '5':
			{
				int searchInput2 = 0;
				bool numberSearched2;
				cout << endl << "Please enter the number you wish to search: ";
				cin >> searchInput2;
				cin.clear();
				cin.ignore(INT_MAX, '\n');
				numberSearched2 = intLinearSearch(intVector, searchInput2);
				if(numberSearched2 == true){
					cout << "The number " << searchInput2 << " is on this list." << endl;
				}//if
				else{
					cout << "The number " << searchInput2 << " is not on this list." << endl;
				}//else
				break;
			}
		case '6':
			{
				for (unsigned int i=0; i<intVector.size(); i++) {
					cout << intVector[i] << endl;
				}//for
				break;
			}
		case 'x':
			break;
		default:
			cout << "Please enter a valid menu option" << endl;
			break;
		}
		cout << endl;
	}while(userInput != 'x');

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
