/*
 * StarShip.hpp
 *
 *  Created on: May 23, 2021
 *      Author: Nicholas Deal
 */

#ifndef STARSHIP_HPP_
#define STARSHIP_HPP_

#include <string>
using namespace std;

class StarShip {
private:
	string designation;
	string shipClass;
	string name;
	int totalCrew;
	double length;
	double maxSpeed;
public:
	StarShip();
	virtual ~StarShip();
	const string& getDesignation() const;
	void setDesignation(const string &designation);
	double getLength() const;
	void setLength(double length);
	double getMaxSpeed() const;
	void setMaxSpeed(double maxSpeed);
	const string& getName() const;
	void setName(const string &name);
	const string& getShipClass() const;
	void setShipClass(const string &shipClass);
	int getTotalCrew() const;
	void setTotalCrew(int totalCrew);
};

#endif /* STARSHIP_HPP_ */
