//============================================================================
// Name        : CS2_Chapter_17_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <map>
#include <list>
#include <iomanip>
#include "StarShip.hpp"
using namespace std;

int main() {

	map<string, StarShip*> starShipMap;
	map<string, StarShip*>::iterator starShipMapIT;
	pair<map<string, StarShip*>::iterator, bool> insertStarShip;
	list<StarShip*> starShipList;
	list<StarShip*>::iterator starShipListIT;
	StarShip* shipPtr = nullptr;
	string shipDesignation;
	string classType;
	string shipName;
	int totalCrewMembers = 0;
	double shiplength = 0.0;
	double shipMaxSpeed = 0.0;
	string userInput;

	ifstream inputFile;
	inputFile.open("StarShipMap.txt");

	while (!inputFile.eof()) {
		shipPtr = new StarShip();
		//getting designation
		inputFile >> shipDesignation;
		try {
			shipPtr->setDesignation(shipDesignation);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		//getting class
		inputFile >> classType;
		try {
			shipPtr->setShipClass(classType);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		//getting name
		inputFile >> shipName;
		try {
			shipPtr->setName(shipName);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		//getting total crew members
		inputFile >> totalCrewMembers;
		try {
			shipPtr->setTotalCrew(totalCrewMembers);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		//getting length
		inputFile >> shiplength;
		try {
			shipPtr->setLength(shiplength);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		//getting max speed
		inputFile >> shipMaxSpeed;
		try {
			shipPtr->setMaxSpeed(shipMaxSpeed);
		}//try
		catch (const string &e) {
			cout << e << endl;
		}//catch
		insertStarShip = starShipMap.insert(pair<string, StarShip*>(shipPtr->getDesignation(), shipPtr));
		if (insertStarShip.second == false) {
			cout << "Star ship with designation " << shipPtr->getDesignation() << " already exists, moving it to an STL list..." << endl;
			starShipList.push_back(shipPtr);
		}//if
		else {
			cout << "Star ship with designation " << shipPtr->getDesignation() << " was inserted successfully." << endl;
		}//else
	}//while

	while (userInput != "end") {
		cout << endl << "Please type the designation of the star-ship you wish to search for" << endl <<
				"\t(type 'end' to exit search, " << endl <<
				"\t type 'all' to display all star-ships, " << endl <<
				"\t type 'dups' to display duplicated star-ships in the STL list): ";
		getline (cin, userInput);
		if (userInput == "end") {
			cout << endl << "\tExiting search..." << endl << endl;
		}//if
		else if (userInput == "all") {
			cout << endl << "Loading all star-ships..." << endl;
			cout << "------------------------------------------------------------------------------------------------------------------" << endl;
			cout << setw(15) << "Designation" << setw(15) << "Name" << setw(18) << "Ship Class" << setw(20) << "Max Crew Members" << setw(15)
					<< "Ship Length" << setw(13) << "Max Speed" << endl;
			cout << setw(15) << "===========" << setw(15) << "====" << setw(18) << "==========" << setw(20) << "================" << setw(15)
					<< "===========" << setw(13) << "=========" << endl;
			for (starShipMapIT = starShipMap.begin();
				 starShipMapIT != starShipMap.end();
				 starShipMapIT++) {
				cout << setw(15) << (*starShipMapIT).second->getDesignation() << setw(15) << (*starShipMapIT).second->getName()
						<< setw(18) << (*starShipMapIT).second->getShipClass() << setw(20) << (*starShipMapIT).second->getTotalCrew()
						<< setw(15) << (*starShipMapIT).second->getLength() << setw(13) << (*starShipMapIT).second->getMaxSpeed() << endl;
			}//for
			cout << "------------------------------------------------------------------------------------------------------------------" << endl;
		}//else if
		else if (userInput == "dups") {
			cout << endl << "Loading all duplicated star-ships in STL list..." << endl;
			cout << "------------------------------------------------------------------------------------------------------------------" << endl;
			cout << setw(15) << "Designation" << setw(15) << "Name" << setw(18) << "Ship Class" << setw(20) << "Max Crew Members" << setw(15)
					<< "Ship Length" << setw(13) << "Max Speed" << endl;
			cout << setw(15) << "===========" << setw(15) << "====" << setw(18) << "==========" << setw(20) << "================" << setw(15)
					<< "===========" << setw(13) << "=========" << endl;
			for (auto listIT: starShipList) {
				cout << setw(15) << listIT->getDesignation() << setw(15) << listIT->getName()
						<< setw(18) << listIT->getShipClass() << setw(20) << listIT->getTotalCrew()
						<< setw(15) << listIT->getLength() << setw(13) << listIT->getMaxSpeed() << endl;
			}//for
			cout << "------------------------------------------------------------------------------------------------------------------" << endl;
		}//else if
		else {
			try {
				starShipMap.at(userInput);
				cout << endl << "Star-ship with designation " << starShipMap.at(userInput)->getDesignation() << " was found!" << endl;
				cout << "Loading star-ship info..." << endl;
				cout << "------------------------------------------------------------------------------------------------------------------" << endl;
				cout << setw(15) << "Designation" << setw(15) << "Name" << setw(18) << "Ship Class" << setw(20) << "Max Crew Members" << setw(15)
						<< "Ship Length" << setw(13) << "Max Speed" << endl;
				cout << setw(15) << "===========" << setw(15) << "====" << setw(18) << "==========" << setw(20) << "================" << setw(15)
						<< "===========" << setw(13) << "=========" << endl;
				cout << setw(15) << starShipMap.at(userInput)->getDesignation() << setw(15) << starShipMap.at(userInput)->getName()
						<< setw(18) << starShipMap.at(userInput)->getShipClass() << setw(20) << starShipMap.at(userInput)->getTotalCrew()
						<< setw(15) << starShipMap.at(userInput)->getLength() << setw(13) << starShipMap.at(userInput)->getMaxSpeed() << endl;
				cout << "------------------------------------------------------------------------------------------------------------------" << endl;
			}
			catch (const std::out_of_range &e) {
				cout << endl << "\t*Error: Star-ship wasn't found*" << endl;
			}//catch

		}//else
	}//while

	for (starShipMapIT = starShipMap.begin();
		 starShipMapIT != starShipMap.end();
		 starShipMapIT++) {
		delete (*starShipMapIT).second;
	}//for

	for (starShipListIT = starShipList.begin();
		 starShipListIT != starShipList.end();
		 starShipListIT++) {
		delete (*starShipListIT);
	}//for

	starShipMap.clear();
	starShipList.clear();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
