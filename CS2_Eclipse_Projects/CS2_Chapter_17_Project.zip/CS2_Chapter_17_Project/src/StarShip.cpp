/*
 * StarShip.cpp
 *
 *  Created on: May 23, 2021
 *      Author: Nicholas Deal
 */

#include "StarShip.hpp"

StarShip::StarShip() {
	// TODO Auto-generated constructor stub

}

const string& StarShip::getDesignation() const {
	return designation;
}

void StarShip::setDesignation(const string &designation) {
	if (designation == "") {
		throw "Error: This string value of the designation has zero length.";
	}//if
	else {
		this->designation = designation;
	}//else
}

double StarShip::getLength() const {
	return length;
}

void StarShip::setLength(double length) {
	if (length <= 0) {
		throw "Error: This numeric value of length is less than or equal to zero.";
	}//if
	else {
		this->length = length;
	}//else
}

double StarShip::getMaxSpeed() const {
	return maxSpeed;
}

void StarShip::setMaxSpeed(double maxSpeed) {
	if (maxSpeed <= 0) {
		throw "Error: This numeric value of the max-speed is less than or equal to zero.";
	}//if
	else {
		this->maxSpeed = maxSpeed;
	}//else
}

const string& StarShip::getName() const {
	return name;
}

void StarShip::setName(const string &name) {
	if (name == "") {
		throw "Error: This string value of the name has zero length.";
	}//if
	else {
		this->name = name;
	}//else
}

const string& StarShip::getShipClass() const {
	return shipClass;
}

void StarShip::setShipClass(const string &shipClass) {
	if (shipClass == "") {
		throw "Error: This string value of the ship-class has zero length.";
	}//if
	else {
		this->shipClass = shipClass;
	}//else
}

int StarShip::getTotalCrew() const {
	return totalCrew;
}

void StarShip::setTotalCrew(int totalCrew) {
	if (totalCrew <= 0) {
		throw "Error: This numeric value of total crew members is less than or equal to zero.";
	}//if
	else {
		this->totalCrew = totalCrew;
	}//else
}

StarShip::~StarShip() {
	// TODO Auto-generated destructor stub
}

