//============================================================================
// Name        : CS21_Numeric_Converter_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>
#include <string>
#include <climits>
#include <cmath>
#include <cstring>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

int main() {

	int menuInput = 0;
	int intInput = 0;
	string binInput;
	int size = 0;
	int total = 0;
	vector<int> binVector;
	vector<char> hexVector;
	bool error = false;

	do {
		cout << "=======================" << endl;
		cout << "1) Decimal to Binary" << endl;
		cout << "2) Binary to Decimal" << endl;
		cout << "3) Decimal to Hex" << endl;
		cout << "4) Hex to Decimal" << endl;
		cout << "9) Exit Program" << endl;
		cout << "=======================" << endl;
		cout << "Please enter one of the displayed options: ";
		cin >> menuInput;
		clearCIN();
		switch (menuInput) {
			case 1:
				cout << "Please enter a decimal number: ";
				cin >> intInput;
				clearCIN();
				if (intInput < 0) {
					cout << "***Error: Decimal value must be greater than or equal to zero." << endl;
					cout << "Returning to menu..." << endl;
					break;
				}//if
				else {
					cout << "Converting decimal value into binary..." << endl;
					while (intInput != 0) {
						binVector.push_back(intInput % 2);
						intInput /= 2;
					}//while
					cout << endl << "Result: ";
					for (int i = (binVector.size() - 1); i >= 0; i--) {
						cout << binVector[i];
					}//for
					cout << endl << endl;
					binVector.clear();
				}//else
				break;
			case 2:
				cout << "Please enter a binary number(1's or 0's) no more than eight digits long: ";
				getline(cin, binInput);
				size = binInput.size();
				if (size > 8) {
					cout << "***Error: Binary number must be no more than eight digits long." << endl;
					cout << "Returning to menu..." << endl;
					break;
				}//if
				else {
					cout << "Converting binary value to decimal..." << endl;
					for (int i = 0; i < size; i++) {
						if ((binInput[i] != '0') && (binInput[i] != '1')) {
							cout << "***Error: Binary number must contain either ones or zeros." << endl;
							cout << "Returning to menu..." << endl;
							error = true;
						}//if
						else {}
					}//for
					if (error == false) {
						for (int i = 0; i < size; i++) {
							total += (static_cast<int>(binInput[i] - 48) * pow(2, size - i - 1));
						}//for
						cout << endl << "Result: " << total << endl << endl;
						total = 0;
					}//if
					else {
						error = false;
						break;
					}//else
				}//else
				break;
			case 3:
				cout << "Please enter a decimal number: ";
				cin >> intInput;
				clearCIN();
				if (intInput < 0) {
					cout << "***Error: Decimal value must be greater than or equal to zero." << endl;
					cout << "Returning to menu..." << endl;
					break;
				}//if
				else {
					cout << "Converting decimal value into hexadecimal..." << endl;
					while (intInput != 0) {
						if (intInput % 16 == 1) {
							hexVector.push_back('1');
							intInput /= 16;
						}//if
						else if (intInput % 16 == 2) {
							hexVector.push_back('2');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 3) {
							hexVector.push_back('3');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 4) {
							hexVector.push_back('4');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 5) {
							hexVector.push_back('5');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 6) {
							hexVector.push_back('6');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 7) {
							hexVector.push_back('7');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 8) {
							hexVector.push_back('8');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 9) {
							hexVector.push_back('9');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 10) {
							hexVector.push_back('A');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 11) {
							hexVector.push_back('B');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 12) {
							hexVector.push_back('C');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 13) {
							hexVector.push_back('D');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 14) {
							hexVector.push_back('E');
							intInput /= 16;
						}//else if
						else if (intInput % 16 == 15) {
							hexVector.push_back('F');
							intInput /= 16;
						}//else if
						else {
							hexVector.push_back('0');
							intInput /= 16;
						}//else
					}//while
					cout << endl << "Result: ";
					if (hexVector.size() == 0) {
						cout << "0";
					}//if
					else {
						for (int i = (hexVector.size() - 1); i >= 0; i--) {
							cout << hexVector[i];
						}//for
					}//else
					cout << endl << endl;
					hexVector.clear();
				}//else
				break;
			case 4:
				cout << "Please enter a hexadecimal number(1-9, a-f) no more than four digits long: ";
				getline(cin, binInput);
				size = binInput.size();
				if (size > 4) {
					cout << "***Error: Hexadecimal number must be no more than 4 digits long." << endl;
					cout << "Returning to menu..." << endl;
					break;
				}//if
				else {
					cout << "Converting binary value to decimal..." << endl;
					for (int i = 0; i < size; i++) {
						if ((binInput[i] != '0')
							&& (binInput[i] != '1')
							&& (binInput[i] != '2')
							&& (binInput[i] != '3')
							&& (binInput[i] != '4')
							&& (binInput[i] != '5')
							&& (binInput[i] != '6')
							&& (binInput[i] != '7')
							&& (binInput[i] != '8')
							&& (binInput[i] != '9')
							&& (binInput[i] != 'a')
							&& (binInput[i] != 'b')
							&& (binInput[i] != 'c')
							&& (binInput[i] != 'd')
							&& (binInput[i] != 'e')
							&& (binInput[i] != 'f')
							&& (binInput[i] != 'A')
							&& (binInput[i] != 'B')
							&& (binInput[i] != 'C')
							&& (binInput[i] != 'D')
							&& (binInput[i] != 'E')
							&& (binInput[i] != 'F')) {
							cout << "***Error: Binary number must contain positve numeric integers or letters a-f." << endl;
							cout << "Returning to menu..." << endl;
							error = true;
						}//if
						else {}
					}//for
					if (error == false) {
						for (int i = 0; i < size; i++) {
							if (binInput[i] == '1') {
								total += (1 * pow(16, size - i - 1));
							}//if
							else if (binInput[i] == '2') {
							total += (2 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '3') {
								total += (3 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '4') {
								total += (4 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '5') {
								total += (5 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '6') {
								total += (6 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '7') {
								total += (7 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '8') {
								total += (8 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == '9') {
								total += (9 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'a' || binInput[i] == 'A') {
								total += (10 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'b' || binInput[i] == 'B') {
								total += (11 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'c' || binInput[i] == 'C') {
								total += (12 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'd' || binInput[i] == 'D') {
								total += (13 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'e' || binInput[i] == 'E') {
								total += (14 * pow(16, size - i - 1));
							}//else if
							else if (binInput[i] == 'f' || binInput[i] == 'F') {
								total += (15 * pow(16, size - i - 1));
							}//else if
							else {}
						}//for
						cout << endl << "Result: " << total << endl << endl;
						total = 0;
					}//if
					else {
						error = false;
						break;
					}//else
				}//else
				break;
			case 9:
				break;
			default:
				cout << "***Error: Please enter a number from the displayed menu..." << endl;
				break;
		}//switch
	} while (menuInput != 9);	//do-while loop

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
