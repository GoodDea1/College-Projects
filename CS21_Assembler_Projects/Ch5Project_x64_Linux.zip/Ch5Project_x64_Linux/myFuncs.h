extern "C" {long long unsigned swapArrays(long long int* array1, long long int* array2, long long int size);}
extern "C" {long long unsigned addArray(long long int* array, long long int size);}
extern "C" {long long int addTwo(long long int num1, long long int num2);}
