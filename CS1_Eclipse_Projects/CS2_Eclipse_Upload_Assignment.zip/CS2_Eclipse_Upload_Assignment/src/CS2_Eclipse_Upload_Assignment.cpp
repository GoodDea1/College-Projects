//============================================================================
// Name        : CS2_Eclipse_Upload_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "My name is Nicholas Deal." << endl;

	cout << "My passion for life is eating good food!" << endl;

	cout << "My major in LPC is Computer Science (Most likely I believe)." << endl;

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
