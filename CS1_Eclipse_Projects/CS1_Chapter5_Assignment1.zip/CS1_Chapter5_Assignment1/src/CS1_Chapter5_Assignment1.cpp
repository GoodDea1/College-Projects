//============================================================================
// Name        : CS1_Chapter5_Assignment1.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <climits>
#include <iomanip>
using namespace std;

int main() {

	int months = 1;
	float month1Sales = 0;
	float month2Sales = 0;
	float month3Sales = 0;
	float month4Sales = 0;
	float month5Sales = 0;
	float month6Sales = 0;
	float totalSales = 0;

	while (months == 1) {
		cout << "Please enter sales for month #1: ";
		cin >> month1Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month1Sales < 0 || month1Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else{
			months++;
			break;
		}//else
	}//while

	while (months == 2) {
		cout << "Please enter sales for month #2: ";
		cin >> month2Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month2Sales < 0 || month2Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else{
			months++;
			break;
		}//else
	}//while

	while (months == 3) {
		cout << "Please enter sales for month #3: ";
		cin >> month3Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month3Sales < 0 || month3Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else{
			months++;
			break;
		}//else
	}//while

	do {
		cout << "Please enter sales for month #4: ";
		cin >> month4Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month4Sales < 0 || month4Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else {
			break;
		}//else
	} while (month4Sales < 0 || month4Sales > 1000000);

	do {
		cout << "Please enter sales for month #5: ";
		cin >> month5Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month5Sales < 0 || month5Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else {
			break;
		}//else
	} while (month5Sales < 0 || month5Sales > 1000000);

	do {
		cout << "Please enter sales for month #6: ";
		cin >> month6Sales;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (month6Sales < 0 || month6Sales > 1000000) {
			cout << "***Error: Inputed value must be greater than 0 or less than 1,000,000.***" << endl;
		}//if
		else {
			break;
		}//else
	} while (month6Sales < 0 || month6Sales > 1000000);

	totalSales = month1Sales + month2Sales + month3Sales + month4Sales + month5Sales + month6Sales;
	cout << fixed << setprecision(2) << showpoint << "Total sales for six months: $"       << totalSales       << endl;
	cout << fixed << setprecision(2) << showpoint << "The average sales for six months: $" << (totalSales/6.0) << endl;

	cout << setw(28) << "Bar Chart by Month" << endl;
	cout << setw(28) << "__________________" << endl;

	//Month #1
	cout << setw(20) << "Month #1: ";
	for (int i = 1, month1Asterisks = month1Sales/100; i <= month1Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month1Sales << ")" << endl;

	//Month #2
	cout << setw(20) << "Month #2: ";
	for (int i = 1, month2Asterisks = month2Sales/100; i <= month2Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month2Sales << ")" << endl;

	//Month #3
	cout << setw(20) << "Month #3: ";
	for (int i = 1, month3Asterisks = month3Sales/100; i <= month3Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month3Sales << ")" << endl;

	//Month #4
	cout << setw(20) << "Month #4: ";
	for (int i = 1, month4Asterisks = month4Sales/100; i <= month4Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month4Sales << ")" << endl;

	//Month #5
	cout << setw(20) << "Month #5: ";
	for (int i = 1, month5Asterisks = month5Sales/100; i <= month5Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month1Sales << ")" << endl;

	//Month #6
	cout << setw(20) << "Month #6: ";
	for (int i = 1, month6Asterisks = month6Sales/100; i <= month6Asterisks; i++) {
		cout << "*";
	}//for
	cout << " ($" << month6Sales << ")" << endl;

	cout << "Program ending, have a nice day!" << endl; // prints Program ending, have a nice day!
	return 0;
}
