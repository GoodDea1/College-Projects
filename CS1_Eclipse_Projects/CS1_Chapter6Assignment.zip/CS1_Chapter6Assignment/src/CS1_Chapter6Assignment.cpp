//============================================================================
// Name        : CS1_Chapter6Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <climits>
#include <cmath>
#include <iomanip>
#include "functions.hpp"
using namespace std;

double CalculateVelocity(double valueOfGravity, double massOfSun, double distanceFromSun);
double CalculatePeriod(double distanceFromSun, double speedOfPlanet);

int main() {

	ifstream inputFile;
	string fileNameInput;
	string planetName;
	double distanceFromSun = 0.0;
	double massOfPlanet = 0.0;

	cout << "Sol Solar System Planetary Summary/Motion Report" << endl;
	cout << "================================================" << endl;
	cout << "Please enter the name of the file which contains the planetary data: ";
	cin >> fileNameInput;
	cout << endl;

	inputFile.open(fileNameInput);

	if (inputFile.fail()) {
		cout << "Error, file could not be opened: " << fileNameInput << endl;
	}//if
	else {
		cout << setw(14) << "Planet" << setw(16) << "Mass (kg)" << setw(19) << "Distance (m)" << setw(26) << "Avg. Orbital Speed (m/s)" << setw(20) << "Orbital Period (y)" << endl;
		cout << setw(14) << "======" << setw(16) << "=========" << setw(19) << "============" << setw(26) << "========================" << setw(20) << "==================" << endl;
		cout << scientific << setprecision(2);
		while(!inputFile.eof()) {
			inputFile >> planetName  >> massOfPlanet >> distanceFromSun;
			double speedOfPlanet = CalculateVelocity(valueOfGravity, massOfSun, distanceFromSun);
			double orbitalPeriod = CalculatePeriod(distanceFromSun, speedOfPlanet);
			cout << setw(14) << planetName << setw(16) << massOfPlanet << setw(19) << distanceFromSun << setw(26) << speedOfPlanet << setw(20) << orbitalPeriod << endl;
		}//while
	}//else

	inputFile.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
