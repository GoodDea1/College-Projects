/*
 * functions.hpp
 *
 *  Created on: Oct 20, 2020
 *      Author: Nicholas Deal
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_
#include <cmath>

const double valueOfGravity = 6.673e-11;
const double massOfSun = 1.989e30;
const double PI = 3.14159;
const double SECONDS = 31536000;

double CalculateVelocity(double valueOfGravity, double massOfSun, double distanceFromSun) {
	double speedOfPlanet;
	speedOfPlanet = sqrt((valueOfGravity*massOfSun)/distanceFromSun);
	return speedOfPlanet;
}

double CalculatePeriod(double distanceFromSun, double speedOfPlanet) {
	double orbitalPeriod;
	orbitalPeriod = ((2*PI*distanceFromSun)/speedOfPlanet)/SECONDS;
	return orbitalPeriod;
}

#endif /* FUNCTIONS_HPP_ */
