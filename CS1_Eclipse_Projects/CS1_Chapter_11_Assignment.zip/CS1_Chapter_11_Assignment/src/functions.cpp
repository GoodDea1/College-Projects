/*
 * functions.cpp
 *
 *  Created on: Nov 19, 2020
 *      Author: Nicholas Deal
 */
#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <cmath>
#include "functions.hpp"
using namespace std;

PlanetType planetTypeConversion(int planetType) {
	PlanetType newPlanetType;
	newPlanetType = static_cast<PlanetType>(planetType);
	return newPlanetType;
}

string TypeToString(PlanetType planet_Type) {
	switch (planet_Type) {
	case Rocky:
		return "Rocky";
	case Gaseous:
		return "Gaseous";
	case Ice:
		return "Ice";
	case Water:
		return "Water";
	case Molten:
		return "Molten";
	default:
		return "Other Type";
	}
}

double CalculateVelocity(double valueOfGravity, double planetMasses, double planetDistance) {
	double speedOfPlanet;
	speedOfPlanet = sqrt((valueOfGravity*massOfSun)/planetDistance);
	return speedOfPlanet;
}

double CalculatePeriod(double distanceFromSun, double speedOfPlanet) {
	double orbitalPeriod;
	orbitalPeriod = ((2*PI*distanceFromSun)/speedOfPlanet)/SECONDS;
	return orbitalPeriod;
}
