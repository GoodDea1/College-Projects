/*
 * functions.hpp
 *
 *  Created on: Nov 19, 2020
 *      Author: Nicholas Deal
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_
using namespace std;

const double valueOfGravity = 6.673e-11;
const double massOfSun = 1.989e30;
const double PI = 3.14159;
const double SECONDS = 31536000;

enum PlanetType {
	Rocky,
	Gaseous,
	Ice,
	Water,
	Molten
};

struct Moon {
	char Name[32];
	double Mass;
	double Distance;
	double Radius;
	PlanetType Type;
};

struct Planet {
	char Name[32];
	double Mass;
	double Distance;
	double Radius;
	PlanetType Type;
	float OrbitalVelocity;
	float OrbitalPeriod;
	vector<Moon> VectorOfMoons;
};

PlanetType planetTypeConversion(int);
string TypeToString(PlanetType);
double CalculateVelocity(double, double, double);
double CalculatePeriod(double, double);

#endif /* FUNCTIONS_HPP_ */
