//============================================================================
// Name        : CS1_Chapter_11_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <iomanip>
#include "functions.hpp"
using namespace std;

int main() {

	vector<Planet> planet;
	ifstream inputFile;
	string inputFileName;
	int type = 0;
	int planetType = 0;
	string planetName;

	cout << "Sol Solar System Planetary Summary/Motion Report" << endl;
	cout << "================================================" << endl;
	cout << endl << "Please enter the name of the file which contains the planetary data: ";
	cin >> inputFileName;
	inputFile.open(inputFileName);

	if (!inputFile.fail()) {
		while (!inputFile.eof()) {
			Planet tempPlanet;
			inputFile >> type;
			if (type == 01) {
				Planet tempPlanet;
				inputFile >> planetName >> planetType >> tempPlanet.Distance >> tempPlanet.Mass;
				strcpy(tempPlanet.Name, planetName.c_str());
				tempPlanet.Type = planetTypeConversion(planetType);
				planet.push_back(tempPlanet);
			}//if
			else if (type == 02) {
				Moon tempMoon;
				inputFile >> planetName >> planetType >> tempMoon.Distance >> tempMoon.Mass;
				strcpy(tempMoon.Name, planetName.c_str());
				tempMoon.Type = planetTypeConversion(planetType);
				planet[planet.size()-1].VectorOfMoons.push_back(tempMoon);
			}
			else {
				cout << "**Error: Could not read if type was a planet or a moon**" << endl;
				inputFile.close();
				break;
			}//else
		}//while
		for (unsigned int i=0; i<=(planet.size()-1); i++) {
			planet[i].OrbitalVelocity = CalculateVelocity(valueOfGravity, planet[i].Mass, planet[i].Distance);
			planet[i].OrbitalPeriod = CalculatePeriod(planet[i].Distance, planet[i].OrbitalVelocity);
		}//for
		cout << endl << "Total Planets read is: " << planet.size() << endl << endl;
		cout << setw(14) << "Planet" << setw(10) << "Type" << setw(17) << "Mass (kg)" << setw(18) << "Distance (m)" << setw(25) << "Avg. Orbital Speed (m/s)" << setw(20) << "Orbital Period (y)" << endl;
		cout << setw(14) << "======" << setw(10) << "====" << setw(17) << "=========" << setw(18) << "============" << setw(25) << "========================" << setw(20) << "==================" << endl;
		cout << scientific << setprecision(2);
		for (unsigned int i=0; i<=(planet.size()-1); i++) {
			cout << setw(14) << planet[i].Name << setw(10) << TypeToString(planet[i].Type) << setw(17) << planet[i].Mass << setw(18) << planet[i].Distance << setw(25) << planet[i].OrbitalVelocity << setw(20) << planet[i].OrbitalPeriod << endl;
			cout << setw(22) << "Moons:" << endl;
			if (planet[i].VectorOfMoons.size() == 0) {
				cout << setw(44) << "No Moons" << endl;
			}//if
			else {
				for (unsigned int k=0; k<=(planet[i].VectorOfMoons.size()-1); k++) {
					cout << setw(31) << planet[i].VectorOfMoons[k].Name << setw(15) << TypeToString(planet[i].VectorOfMoons[k].Type) << endl;
				}//for
			}//else
			cout << setw(24) << "-------------------" << endl;
		}//for
	}//if
	else {
		cout << "**Error: The name of the file you typed in didn't seem to work**" << endl;
	}//else

	inputFile.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
