//============================================================================
// Name        : CS1_Chapter4_Assignment1.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <climits>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {

	char menuInput;
	string planetName;
	double planetMass = 0.0;
	double distanceFromPlanet = 0.0;
	double speedOfSatellite = 0.0;
	const double valueOfGravity = 6.673e-11;

	/*
	 * Main Menu
	 * =========
	 * Enter <P>lanet Name
	 * Enter Planet <M>ass
	 * Enter Satellite <D>istance from the Planet
	 * <C>alculate Speed
	 * E<X>it the Program
	 * Please enter a selection
	 * 		Planet Name		Planet Mass	Orbit Distance   Orbital speed m/s
	 * 		===========		===========	==============   =================
	 * 			  Earth		   5.98e+24		  6.78e+06			   7671.78
	 */

	//Selection Menu
	mainMenu:

	cout << "Main Menu" << endl;
	cout << "=========" << endl;
	cout << "Enter <P>lanet Name" << endl;
	cout << "Enter Planet <M>ass" << endl;
	cout << "Enter Satellite <D>istance from the Planet" << endl;
	cout << "<C>alculate Speed" << endl;
	cout << "E<X>it the Program" << endl;
	cout << "Please enter a selection: ";

	cin >> menuInput;

	//Conditions for menu options
		if (menuInput == 'P' || menuInput == 'p') {
			cout << "What is the planet's name?" << endl;
			cin >> planetName;
			goto mainMenu;
		}//if
		else if (menuInput == 'M' || menuInput == 'm') {
			cout << "What is the planet's mass (in kilograms)?" << endl;
			cin >> planetMass;
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			if (planetMass < 0) {
				cout << "Input Error: Value must be greater than zero." << endl;
				goto mainMenu;
			}//if
			else {
				goto mainMenu;
			}//else
		}//else if
		else if (menuInput == 'D' || menuInput == 'd') {
			cout << "What is the distance between the satellite and the planet (in meters)?" << endl;
			cin >> distanceFromPlanet;
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			if (distanceFromPlanet < 0) {
				cout << "Input Error: Value must be greater than zero." << endl;
				goto mainMenu;
			}//if
			else {
				goto mainMenu;
			}//else
		}//else if
		//Report table displaying the name, values inputed, and the resulting speed
		else if (menuInput == 'C' || menuInput == 'c') {
			speedOfSatellite = sqrt((valueOfGravity*planetMass)/distanceFromPlanet);
			cout << setw(16) << right << "Planet Name" << setw(16) << right << "Planet Mass" << setw(15) << right << "Orbit Distance"   << setw(20) << right << "Orbital speed m/s" << endl;
			cout << setw(16) << right << "===========" << setw(16) << right << "===========" << setw(15) << right << "=============="   << setw(20) << right << "=================" << endl;
			cout << setw(16) << right << planetName    << setw(16) << right << planetMass    << setw(15) << right << distanceFromPlanet << setw(20) << right << speedOfSatellite    << endl;
			if (planetMass == 0.0) {
				cout << "Input Error: The planet's mass wasn't inputed. Please try again." << endl;
				goto mainMenu;
			}//if
			else if (distanceFromPlanet == 0.0) {
				cout << "Input Error: The satellite's distance from the planet wasn't inputed. Please try again." << endl;
				goto mainMenu;
			}//else if
			else if (speedOfSatellite == 0.0) {
				cout << "Input Error: Either the input values are too small, or one or both of the values wasn't inputed. Please try again." << endl;
				goto mainMenu;
			}//else if
			else {
				goto mainMenu;
			}//else
		}//else if
		else if (menuInput == 'X' || menuInput == 'x') {
			cout << "Program ending, have a nice day!" << endl; // prints Program ending, have a nice day!
		}//else if
		else {
			cout << "Input is invalid, please try again." << endl;
			goto mainMenu;
		}//else
	return 0;
}
