//============================================================================
// Name        : CS1_InClass_DoWhile_Loop_Practice.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <climits>
using namespace std;

int main() {

	int counter = 10;
	int total = 0;
	int userInput = 0;
	//it's always good to use unsigned ints with counters
	const unsigned int STARTINGVALUE = 0;
	const unsigned int ENDINGVALUE = 999;

	unsigned int i = 0;
	unsigned int user_Input = 0;

//1
	while (counter > 0) {
		total = counter * 200;
		cout << "Counter is: " << total << endl;
		counter--;
	}//while

//2
	counter = 10;
	total = 0;
	do{
		total = counter * 200;
		cout << "Counter is: " << total << endl;
		counter--;
	}while (counter > 0);

//3
	cout << "Please enter a value between 1 and 50000 (enter -999 to exit the program): ";
	cin >> userInput;
	cin.clear();
	cin.ignore(INT_MAX, '\n');
		while (userInput > 1 && userInput < 50000) {
			if (userInput == -999) {
				break;
			}//if
			else {
				cout << "You've entered: " << userInput << endl;
				break;
			}//else
		}//while
		if (userInput <= 1 || userInput >= 50000) {
			cout << "Error: The value that you inputed must be greater than 1 or less than 50000." << endl;
		}//if
		else {}

//4
	cout << "Please enter a value between 1 and 50000 (enter -999 to exit the program): ";
	cin >> userInput;
	cin.clear();
	cin.ignore(INT_MAX, '\n');
		do {
			if (userInput == -999) {
				break;
			}//if
			else if (userInput <= 1 || userInput >= 50000) {
				cout << "Error: The value that you inputed must be greater than 1 or less than 50000." << endl;
				break;
			}
			else {
				cout << "You've entered: " << userInput << endl;
				break;
			}//else
		}while (userInput > 1 && userInput < 50000);

//for-loop demonstration
//don't change the counter value inside the for-loop, EVER
//	int x = 0;
	for (i = STARTINGVALUE; i <= ENDINGVALUE; i++) {
		cout << "That value of i is: " << i << endl;
//		x = i * i;
		cout << "The value of i raised to the power of 2 is: " << (i*i) << endl;
	}//for

	cout << "Please enter the number of times you want the loop to execute: ";
	cin >> userInput;
	cin.clear();
	cin.ignore(INT_MAX, '\n');
	for (unsigned int j = 0; j < user_Input; j++) {
		cout << "I have incremented: " << j << " times." << endl;
	}//for

	char userGender;
	cout << "Please enter your gender (F = Female, M = Male, O = Other: ";
	cin >> userGender;
	for (unsigned int j = 0; j < 5 && userGender == 'F'; j++) {
		cout << "Congratulations! (you also deserve equal pay!)" << endl;
	}//for

//For Loop Practice #1
//1
	for (unsigned int i = 10; i < 60; i++) {
		cout << "Counter is at: " << i << endl;
	}//for

//2
	for (unsigned int i = 10; i <= 50; i += 2) {
		cout << "Counter is at: " << i << endl;
	}//for

//3
	double result = 0;
	for (unsigned int i = 0; i <= 100; i++) {
		result = i/2.0;
		cout << "counter is at: " << result << endl;
	}//for

//4
	int caloriesAte = 0;
	int TOTAL = 0;
	for (unsigned int i = 0; i < 3; i++) {
		cout << "Please enter the number of calories you ate: ";
		cin >> caloriesAte;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (caloriesAte < 0) {
			cout << "Negative values are not allowed" << endl;
			i--;
		}//if
		else{
			TOTAL += caloriesAte;
		}//else
	}//for
	if (total > 2000) {
		cout << "Welp, looks like you need to eat " << total - 2000 << " less calories." << endl;
	}//if
	else{
	cout << "You can eat " << 2000 - total << " more calories." << endl;
	}//else
//
//5
	unsigned int p = 0;
	int number = 0;
	int finalResult = 0;
	for (; p <= 100; p++) {
		cout << "Type in a number (type -999 to leave): ";
		cin >> number;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		if (number == -999) {
			break;
		}//if
		else {
			finalResult += number;
		}//else
	}//for
	if (i == 0) {
		cout << "There was no input." << endl;
	}//if
	else {
		cout << "The average number inputed is " << finalResult/p << endl;
	}//else

//6
	double itemCost = 0;
	double itemSum = 0;
	double sumTotal = 0;
	for (unsigned int i = 1; i <= 5 ; i++) {
		itemSum = 0;
		for (unsigned int k = 0; k < 3; k++) {
			cout << "Type the cost of the item ordered: ";
			cin >> itemCost;
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			if (itemCost < 0) {
				cout << "The cost can't be a negative number." << endl;
				k--;
			}//if
			else {
				itemSum += itemCost;
			}//else
		}//for
		cout << "Order " << i << " is $" << itemSum << endl;
		sumTotal += itemSum;
	}//for
	cout << "The total of the 5 orders is $" << sumTotal << endl;

	cout << "Program ending, have a nice day!" << endl; // prints Program ending, have a nice day!
	return 0;
}
