/*
 * functions.cpp
 *
 *  Created on: Dec 3, 2020
 *      Author: Nicholas Deal
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <climits>
#include <vector>
#include <fstream>
#include "functions.hpp"
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

void inputCookie(vector<Cookie> &cookieVector) {

	Cookie tempCookie;
	char name[32];
	int calories = 0;
	float cost = 0.0;
	float price = 0.0;
	int stock = 0;

	cout << "\nPlease enter the name of the cookie: ";
	cin.getline(name, 32);
	strcpy(tempCookie.CookieName, name);
	cout << "Please enter the calories: ";
	cin >> calories;
	clearCIN();
	tempCookie.CookieCalories = calories;
	cout << "Please enter the cost: ";
	cin >> cost;
	clearCIN();
	tempCookie.CookieCost = cost;
	cout << "Please enter the price: ";
	cin >> price;
	clearCIN();
	tempCookie.CookiePrice = price;
	cout << "Please enter the total cookies in stock: ";
	cin >> stock;
	clearCIN();
	tempCookie.TotalCookiesInStock = stock;
	cookieVector.push_back(tempCookie);
	cout << endl;
}//inputCookies

void printCookies(vector<Cookie> &cookieVector) {
	int totalCookies = 0;
	cout << endl << "Cookie Report" << endl;
	cout << "=============" << endl;
	cout << setw(34) << left << "Name";
	cout << setw(9) << right << "Calories" << setw(9) << "Cost" << setw(9) << "Price" << setw(9) << "Profit" << setw(16) << "Total on Hand" << endl;
	cout << setw(34) << left << "--------------------------";
	cout << setw(9) << right << "--------" << setw(9) << "--------" << setw(9) << "--------" << setw(9) << "--------" << setw(16) << "-------------" << endl;
	for (unsigned int i = 0; i < cookieVector.size(); i++) {
		cout << fixed << setprecision(2);
		cout << setw(34) << left << cookieVector[i].CookieName;
		cout << setw(9) << right << cookieVector[i].CookieCalories << setw(9) << cookieVector[i].CookieCost << setw(9);
		cout << cookieVector[i].CookiePrice << setw(9) << (cookieVector[i].CookiePrice - cookieVector[i].CookieCost) << setw(16) << cookieVector[i].TotalCookiesInStock << endl;
		totalCookies += cookieVector[i].TotalCookiesInStock;
	}//for
	cout << "Total Cookies in inventory is: " << totalCookies << endl;
	cout << endl;
}//printCookies

void readCookies(vector<Cookie> &cookieVector) {
	fstream inputFile;
	Cookie theCookie;
	inputFile.open("Cookies.bin", ios::in | ios::binary);
	if (inputFile.fail()) {
		cout << "**Error: File does not exist**" << endl;
	}//if
	else {
		inputFile.seekg(0L, ios::beg);
		while(true) {
			inputFile.read(reinterpret_cast<char *>(&theCookie), sizeof(theCookie));
			if (inputFile.eof()) {
				inputFile.close();
				break;
			}//if
			else {
				cookieVector.push_back(theCookie);
			}//else
		}//while
	}//else
}//readCookies

void writeCookies(vector<Cookie> &cookieVector) {
	fstream outputFile;
	Cookie theCookie;
	outputFile.open("Cookies.bin", ios::out | ios::binary);
	outputFile.seekp(0L, ios::beg);
	for (unsigned int i=0; i<cookieVector.size(); i++) {
		outputFile.write(reinterpret_cast<char*>(&cookieVector[i]), sizeof(cookieVector[i]));
	}//for
	outputFile.close();
}//writeCookies

void updateCookies(void) {
	fstream inputFile;
	fstream outputFile;
	Cookie tempCookie;
	float percentValue = 0;
	cout << "Please enter the percentage that you want to increase the price and cost (0 - 100): ";
	cin >> percentValue;
	clearCIN();
	inputFile.open("Cookies.bin", ios::in | ios::binary);
	outputFile.open("CookiesNew.bin", ios::out | ios::binary);
	while(true) {
		inputFile.read(reinterpret_cast<char *>(&tempCookie), sizeof(tempCookie));
		if (inputFile.eof()) {
			inputFile.close();
			break;
		}//if
		else {
			tempCookie.CookieCost = tempCookie.CookieCost + (tempCookie.CookieCost * (percentValue/100.00));
			tempCookie.CookiePrice = tempCookie.CookiePrice + (tempCookie.CookiePrice * (percentValue/100.00));
			outputFile.write(reinterpret_cast<char*>(&tempCookie), sizeof(tempCookie));

		}//else
	}//while
	outputFile.close();
}//udpateCookies

void printUpdatedCookies(void) {
	vector<Cookie> cookieVector;
	fstream inputFile;
	Cookie tempCookie;
	int totalCookies = 0;
	inputFile.open("CookiesNew.bin", ios::in | ios::binary);
	if (inputFile.fail()) {
		cout << "**Error: File does not exist**" << endl;
	}//if
	else {
		inputFile.seekg(0L, ios::beg);
		while(true) {
			inputFile.read(reinterpret_cast<char *>(&tempCookie), sizeof(tempCookie));
			if (inputFile.eof()) {
				inputFile.close();
				break;
			}//if
			else {
				cookieVector.push_back(tempCookie);
			}//else
		}//while
	}//else
	cout << endl << "UPDATED Cookie Report" << endl;
	cout << "=============" << endl;
	cout << setw(34) << left << "Name";
	cout << setw(9) << right << "Calories" << setw(9) << "Cost" << setw(9) << "Price" << setw(9) << "Profit" << setw(16) << "Total on Hand" << endl;
	cout << setw(34) << left << "--------------------------";
	cout << setw(9) << right << "--------" << setw(9) << "--------" << setw(9) << "--------" << setw(9) << "--------" << setw(16) << "-------------" << endl;
	for (unsigned int i = 0; i < cookieVector.size(); i++) {
		cout << fixed << setprecision(2);
		cout << setw(34) << left << cookieVector[i].CookieName;
		cout << setw(9) << right << cookieVector[i].CookieCalories << setw(9) << cookieVector[i].CookieCost << setw(9);
		cout << cookieVector[i].CookiePrice << setw(9) << (cookieVector[i].CookiePrice - cookieVector[i].CookieCost) << setw(16) << cookieVector[i].TotalCookiesInStock << endl;
		totalCookies += cookieVector[i].TotalCookiesInStock;
	}//for
	cout << "Total Cookies in inventory is: " << totalCookies << endl;
	cout << endl;
	inputFile.close();
}//printUpdatedCookies
