/*
 * functions.hpp
 *
 *  Created on: Dec 3, 2020
 *      Author: Nicholas Deal
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_
using namespace std;

struct Cookie {
	char CookieName[32];
	int CookieCalories = 0;
	float CookieCost = 0.0;
	float CookiePrice = 0.0;
	int TotalCookiesInStock = 0;
};

void clearCIN(void);
void inputCookie(vector<Cookie>&);
void printCookies(vector<Cookie>&);
void readCookies(vector<Cookie>&);
void writeCookies(vector<Cookie>&);
void updateCookies(void);
void printUpdatedCookies(void);

#endif /* FUNCTIONS_HPP_ */
