//============================================================================
// Name        : Programming.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
