//============================================================================
// Name        : CS1_Decisions_1.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <climits>
using namespace std;

int main() {
	int userWeight = 0;

	startOfProgram:		//label
		cout << "Please enter your weight: ";

		cin >> userWeight;
		cin.clear();
		cin.ignore(INT_MAX, '\n');

		if(userWeight > 0) {
			if(userWeight > 200) {
				cout << "Jenny Craig?" << endl;
			}//if
			else {
				cout << "You're either sick or you're in good shape!" << endl;
			}//else
		}//if
		else {
			cout << "Invalid weight, please try again" << endl;
			goto startOfProgram;
		}//else

	cout << "Program ending, have a nice day!" << endl;	//prints Program ending, have a nice day!
	return 0;
}
