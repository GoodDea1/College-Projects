//============================================================================
// Name        : Chapter2Assignment.cpp
// Author      : Nicholas Deal
// Version     : 1.0
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	int numberOfShares = 750;
	double costPerShare = 35.22;
	double commissionValue = 0.02;
	double totalPaid = 0;
	double totalCostOfShares = numberOfShares * costPerShare;
	cout << "Kathryn has bought $" << totalCostOfShares << " worth of shares without commission." << endl; 	//Prints message displaying total cost of shares
	cout << "The value of the commission is " << commissionValue << "." <<endl;						//Prints message displaying the percentage value of the commission
	totalPaid = totalCostOfShares + (commissionValue * totalCostOfShares);								//Calculates the total amount paid including commissions
	cout << "The total amount paid plus commission is $" << totalPaid << "." << endl;						//Prints message displaying total payment including commissions
	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
