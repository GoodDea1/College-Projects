//============================================================================
// Name        : CS1Lecture5.cpp
// Author      : Nicholas Deal
// Version     : 1.0
// Copyright   : Don't copy this if you don't like losing money!
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

//Global Variable (Don't use this, ever)
//These are for very bad and lazy people
//int myGlobalVariable = 10;

int main() {

//	int myGlobalVariable = 20;
	bool yesOrNo = true;

//	const double gravConst = 6.45;
	const int monthsInYear = 12;
//	const double hoursInADay = 23.54;
//	const double valueOfPi = 3.14159;

	long longVar = 0;
	long long longLongVar = 0;
	double doubleVar = 0.0;

	cout << monthsInYear << endl;

	yesOrNo = true;				//this is a comment

	if (yesOrNo) {
		cout << "The value of yesOrNo is true" << endl;
	}//if
	else {
		cout << "The value of yesOrNo is false" << endl;
	}//else
	if (yesOrNo == true) {
		cout << "The value of yesOrNo is true" << endl;
		int tempVariable;
		tempVariable = 900;
		cout << tempVariable << endl;
	}//if
	else {
		cout << "The value of yesOrNo is false" << endl;
	}//else

	cout << "yesOrNo is: " << sizeof(yesOrNo) << " bytes in size" << endl;
	cout << "longVar is: " << sizeof(longVar) << " bytes in size" << endl;
	cout << "longLongVar is: " << sizeof(longLongVar) << " bytes in size" << endl;
	cout << "doubleVar is: " << sizeof(doubleVar) << " bytes in size" << endl;

/*
	int myStrangeIntVariable;
	//Scope = what can be seen from where
	{
		int myStrangeIntVariable = 99;
		myStrangeIntVariable = 200;
	}


	myStrangeIntVariable = 400;
*/
	cout << 13 / 2 << endl;
	cout << 13.0 / 2 << endl;      //double has a higher precedence than integer
	cout << 12.0 / 2.0 << endl;

	int onceADouble = 0;
	double iAmADouble = 99.99999;

	onceADouble = iAmADouble + .05;    //round up the double
	cout << onceADouble << endl;

	cout << "Program ending, have a nice day! :)" << endl;
	return 0;
}//main
