//============================================================================
// Name        : CS1_Chapter_12_Assignment.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
#include <cstring>
#include <climits>
#include <vector>
#include <fstream>
#include "functions.hpp"
using namespace std;

int main() {

	vector<Cookie> cookieVector;
	int userInput = 0;

	do {
		cout << "Main Menu" << endl;
		cout << "=========" << endl;
		cout << "1. Enter a Cookie" << endl;
		cout << "2. Print the Cookies" << endl;
		cout << "3. Clear the Cookies" << endl;
		cout << "4. Read the Cookies.bin file" << endl;
		cout << "5. Write the Cookies.bin file" << endl;
		cout << "6. Update Price of All cookies" << endl;
		cout << "7. Print updated cookie file" << endl;
		cout << "8. Read a random cookie from the file" << endl;
		cout << "9. Exit the program" << endl;
		cout << "Please select an option: ";
		cin >> userInput;
		clearCIN();
		switch (userInput) {
			case 1:
				inputCookie(cookieVector);
				break;
			case 2:
				printCookies(cookieVector);
				break;
			case 3:
				while(cookieVector.size() > 0) {
					cookieVector.pop_back();
				}//while
				cout << endl;
				break;
			case 4:
				readCookies(cookieVector);
				break;
			case 5:
				writeCookies(cookieVector);
				break;
			case 6:
				updateCookies();
				break;
			case 7:
				printUpdatedCookies();
				break;
			case 8:
				chooseCookie();
				break;
			default:
				break;
		}//switch
	} while (userInput != 9);

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
