//============================================================================
// Name        : CS1_Chapter_7_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <iomanip>
#include "functions.hpp"
using namespace std;

const int ARRAYSIZE = 50;

int main() {

	ifstream inputFile;
	string fileNameInput;
	string planetName;
	string planetNames[ARRAYSIZE];
	double planetMasses[ARRAYSIZE];
	double planetDistance[ARRAYSIZE];
	double planetVelocity[ARRAYSIZE];
	float planetPeriod[ARRAYSIZE];
	int totalPlanets = 0;

	cout << "Sol Solar System Planetary Summary/Motion Report" << endl;
	cout << "================================================" << endl;
	cout << "Please enter the name of the file which contains the planetary data: ";
	cin >> fileNameInput;
	cout << endl;

	if (inputFile.fail()) {
		cout << "Error, file could not be opened: " << fileNameInput << endl;
	}//if
	else {
		totalPlanets = readPlanets(fileNameInput, planetNames, planetMasses, planetDistance);
		calcPlanets(fileNameInput, planetNames, planetMasses, planetDistance, planetVelocity, planetPeriod, totalPlanets);
		printPlanets(fileNameInput, planetNames, planetMasses, planetDistance, planetVelocity, planetPeriod, totalPlanets);
	}//else

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
