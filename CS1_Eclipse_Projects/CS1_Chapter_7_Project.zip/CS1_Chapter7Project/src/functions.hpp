/*
 * functions.hpp
 *
 *  Created on: Oct 29, 2020
 *      Author: Nicholas Deal
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_
#include <string>
#include <fstream>
using namespace std;

const double valueOfGravity = 6.673e-11;
const double massOfSun = 1.989e30;
const double PI = 3.14159;
const double SECONDS = 31536000;

double CalculateVelocity(double, double[], double);
double CalculatePeriod(double, double);
int readPlanets(string, string[], double[], double[]);
void calcPlanets(string, string[], double[], double[], double[], float[], int);
void printPlanets(string, string[], double[], double[], double[], float[], int);

#endif /* FUNCTIONS_HPP_ */
