/*
 * functions.cpp
 *
 *  Created on: Oct 29, 2020
 *      Author: Nicholas Deal
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include "functions.hpp"
using namespace std;

double CalculateVelocity(double valueOfGravity, double planetMasses, double planetDistance) {
	double speedOfPlanet;
	speedOfPlanet = sqrt((valueOfGravity*massOfSun)/planetDistance);
	return speedOfPlanet;
}

double CalculatePeriod(double distanceFromSun, double speedOfPlanet) {
	double orbitalPeriod;
	orbitalPeriod = ((2*PI*distanceFromSun)/speedOfPlanet)/SECONDS;
	return orbitalPeriod;
}

int readPlanets(string fileNameInput, string planetNames[], double planetMasses[], double planetDistances[]) {
	ifstream input_File;
	input_File.open(fileNameInput);
	int x = 0;
	for (; x<50; x++) {
		input_File >> planetNames[x] >> planetDistances[x] >> planetMasses[x];
		if (!input_File.eof()) {
			continue;
		}//if
		else {
			break;
		}//else
	}//for
	input_File.close();
	return x + 1;
}

void calcPlanets(string fileNameInput, string planetNames[], double planetMasses[], double planetDistances[], double planetVelocity[], float planetPeriod[], int totalPlanets) {
	ifstream input_File;
	input_File.open(fileNameInput);
	for (int i=0; i<totalPlanets; i++) {
		input_File >> planetNames[i] >> planetDistances[i] >> planetMasses[i];
		planetVelocity[i] = CalculateVelocity(valueOfGravity, planetMasses[i], planetDistances[i]);
		planetPeriod[i] = CalculatePeriod(planetDistances[i], planetVelocity[i]);
		if (!input_File.eof()) {
			continue;
		}//if
		else {
			break;
		}//else
	}//for
	input_File.close();
}

void printPlanets(string fileNameInput, string planetNames[], double planetMasses[], double planetDistances[], double planetVelocity[], float planetPeriod[], int totalPlanets) {
	ifstream input_File;
	input_File.open(fileNameInput);
	cout << setw(14) << "Planet" << setw(16) << "Mass (kg)" << setw(19) << "Distance (m)" << setw(26) << "Avg. Orbital Speed (m/s)" << setw(20) << "Orbital Period (y)" << endl;
	cout << setw(14) << "======" << setw(16) << "=========" << setw(19) << "============" << setw(26) << "========================" << setw(20) << "==================" << endl;
	cout << scientific << setprecision(2);
	for (int i=0; i<totalPlanets; i++) {
		input_File >> planetNames[i] >> planetDistances[i] >> planetMasses[i] ;
		cout << setw(14) << planetNames[i] << setw(16) << planetMasses[i] << setw(19) << planetDistances[i] << setw(26) << planetVelocity[i] << setw(20) << planetPeriod[i] << endl;
		if (!input_File.eof()) {
			continue;
		}//if
		else {
			break;
		}//else
	}//for
	input_File.close();
}
