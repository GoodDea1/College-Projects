//============================================================================
// Name        : CS1_ParallelArays.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
#include <climits>
using namespace std;

void clearCIN(void) {
	cin.clear();
	cin.ignore(INT_MAX, '\n');
}

int main() {

	const int MAXANIMALS = 100;
	string animalSpecies[MAXANIMALS];
	int animalPop[MAXANIMALS];
	float animalLifeSpan[MAXANIMALS];
	int animalCounter = 0;
	string inputSpecies;
	int inputPop;
	float inputLifeSpan;

//	animalSpecies[0] = "Squirel"; animalCounter++;
//	animalSpecies[1] = "Tiger"; animalCounter++;
//	animalSpecies[2] = "Giraffe"; animalCounter++;
//	animalSpecies[3] = "Chimpanzee"; animalCounter++;
//	animalSpecies[4] = "African Lion"; animalCounter++;
//	animalSpecies[5] = "Lemur"; animalCounter++;
//
//	animalPop[0] = 14;
//	animalPop[1] = 6;
//	animalPop[2] = 8;
//	animalPop[3] = 14;
//	animalPop[4] = 8;
//	animalPop[5] = 14;
//
//	animalLifeSpan[0] = 2.5;
//	animalLifeSpan[1] = 32;
//	animalLifeSpan[2] = 18.5;
//	animalLifeSpan[3] = 45;
//	animalLifeSpan[4] = 27;
//	animalLifeSpan[5] = 8;

	for (int i=0; i<MAXANIMALS; i++) {
		cout << "Please enter an animal species (-999 to quit): ";
		getline(cin, inputSpecies);
		if (inputSpecies == "-999") break;
		cout << "Please enter the lifespan of a " << inputSpecies << ": ";
		cin >> inputLifeSpan;
		clearCIN();
		cout << "Please enter the current population of " << inputSpecies << ": ";
		cin >> inputPop;
		clearCIN();
		animalSpecies[i] = inputSpecies;
		animalPop[i] = inputPop;
		animalLifeSpan[i] = inputLifeSpan;
		animalCounter++;
	}//for

		for (int i=0; i<animalCounter; i++) {
		cout << setw(20) << animalSpecies[i] << " has a population of: " << setw(8) << animalPop[i]
				<< " each may live "
				<< setw(8) << fixed << setprecision(2) << animalLifeSpan[i] << " years." << endl;
	}//for

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
