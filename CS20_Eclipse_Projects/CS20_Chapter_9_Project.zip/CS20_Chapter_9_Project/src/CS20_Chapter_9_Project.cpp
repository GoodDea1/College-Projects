//============================================================================
// Name        : CS20_Chapter_9_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include "Employee.hpp"
#include "Hash.hpp"
using namespace std;

int main() {

	Hash TheHash;
	Employee* theEmployee;
	Employee* searchEmployee;
	ifstream inputFile;
	string employeeID;
	string lastName;
	string firstName;
	double employeeSalary = 0;
	string userInput;

	inputFile.open("EmployeeFile.txt");
	while (!inputFile.eof()) {
		inputFile >> employeeID >> lastName >> firstName >> employeeSalary;
		theEmployee = new Employee();
		theEmployee->ID = employeeID;
		theEmployee->lastName = lastName;
		theEmployee->firstName = firstName;
		theEmployee->salary = employeeSalary;
		if (TheHash.Insert(employeeID, theEmployee) == false) {
			cout << "***Error: Something went wrong while inserting the employee into the hash table." << endl;
		}//if
		else {}
	}//while

	cout << endl << "The total amount of collisions using the CollisionCount function is " << TheHash.CollisionCount() << " collisions." << endl;
	TheHash.PrintCollisionCount();

	while (userInput != "end") {
		cout << "Please enter an employee key('end' to exit): ";
		cin >> userInput;
		searchEmployee = TheHash.Find(userInput);
		if (searchEmployee == nullptr) {
			if (userInput != "end") {
				cout << "***Error: Couldn't find employee." << endl << endl;
			}//if
			else {}
		}//if
		else {
			cout << endl << "Employee ID: " << searchEmployee->ID << endl;
			cout << "Name: " << searchEmployee->firstName << " " << searchEmployee->lastName << endl;
			cout << "Salary: " << searchEmployee->salary << endl << endl;
		}//else
	}//while

	inputFile.close();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
