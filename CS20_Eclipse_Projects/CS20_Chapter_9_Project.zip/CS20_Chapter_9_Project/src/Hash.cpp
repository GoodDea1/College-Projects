/*
 * Hash.cpp
 *
 *  Created on: Nov 2, 2021
 *      Author: Nicholas Deal
 */

#include "Hash.hpp"

Hash::Hash() {
	// TODO Auto-generated constructor stub
	this->hashTable = new Employee**[500];

	for (int i=0; i<500; i++) {
		this->hashTable[i] = new Employee*[50];
		for (int j=0; j<50; j++) {
			this->hashTable[i][j] = nullptr;
		}//for
	}//for
}//constructor

bool Hash::Insert(string key, Employee* newEmployee) {
	int hashValue = 0;
	int hashIndex = 0;
	bool result = false;
	for(unsigned int i = 0; i < key.size(); i++) {
		hashValue += static_cast<int>(key[i]);
	}//for
	//hashValue *= static_cast<int>(key[4]);
	hashIndex = hashValue % 500;
	if (this->hashTable[hashIndex][0] == nullptr) {
		this->hashTable[hashIndex][0] = newEmployee;
		result = true;
	}//if
	else {
		for (int i=0; i<250; i++) {
			if (this->hashTable[(hashIndex + (i*2)) % 500][0] == nullptr) {
				this->hashTable[(hashIndex + (i*2)) % 500][0] = newEmployee;
				result = true;
				break;
			}//if
			else {}
		}//for
		if (result == false) {
			for (int i=0; i<250; i++) {
				if (this->hashTable[(hashIndex + ((i*2)+1)) % 500][0] == nullptr) {
					this->hashTable[(hashIndex + ((i*2)+1)) % 500][0] = newEmployee;
					result = true;
					break;
				}//if
				else {}
			}//for
			if (result == false) {
				for (int i=0; i<50; i++) {
					if (this->hashTable[hashIndex][i] == nullptr) {
						this->hashTable[hashIndex][i] = newEmployee;
						result = true;
						break;
					}//if
					else {}//else
				}//for
			}//if
			else {}
		}//if
	}//else
	return result;
}//Insert

Employee* Hash::Find(string key) {
	int hashValue = 0;
	int hashIndex = 0;
	Employee* result = nullptr;
	for(unsigned int i = 0; i < key.size(); i++) {
		hashValue += static_cast<int>(key[i]);
	}//for
	//hashValue *= static_cast<int>(key[4]);
	hashIndex = hashValue % 500;
	if (this->hashTable[hashIndex][0] != nullptr) {
		if (this->hashTable[hashIndex][0]->ID == key) {
			result = this->hashTable[hashIndex][0];
		}//if
		else {
			for (int i=0; i<250; i++) {
				if (this->hashTable[(hashIndex + (i*2)) % 500][0] != nullptr) {
					if (this->hashTable[(hashIndex + (i*2)) % 500][0]->ID == key) {
						result = this->hashTable[(hashIndex + (i*2)) % 500][0];
						break;
					}//if
					else {}
				}//if
				else {}
			}//for
			if (result == nullptr) {
				for (int i=0; i<250; i++) {
					if (this->hashTable[(hashIndex + ((i*2)+1)) % 500][0] != nullptr) {
						if (this->hashTable[(hashIndex + ((i*2)+1)) % 500][0]->ID == key) {
						result = this->hashTable[(hashIndex + ((i*2)+1)) % 500][0];
						break;
						}//if
						else {}
					}//if
				}//for
				if (result == nullptr) {
					for (int i=0; i<50; i++) {
						if (this->hashTable[hashIndex][i] != nullptr) {
							if (this->hashTable[hashIndex][i]->ID == key) {
								result = this->hashTable[hashIndex][i];
								break;
							}//if
							else {}//else
						}//if
						else {}
					}//for
				}//if
				else {}
			}//if
		}//else
	}//if
	else {
		for (int i=0; i<250; i++) {
			if (this->hashTable[(hashIndex + (i*2)) % 500][0] != nullptr) {
				if (this->hashTable[(hashIndex + (i*2)) % 500][0]->ID == key) {
					result = this->hashTable[(hashIndex + (i*2)) % 500][0];
					break;
				}//if
				else {}
			}//if
			else {}
		}//for
		if (result == nullptr) {
			for (int i=0; i<250; i++) {
				if (this->hashTable[(hashIndex + ((i*2)+1)) % 500][0] != nullptr) {
					if (this->hashTable[(hashIndex + ((i*2)+1)) % 500][0]->ID == key) {
						result = this->hashTable[(hashIndex + ((i*2)+1)) % 500][0];
						break;
					}//if
					else {}
				}//if
				else {}
			}//for
			if (result == nullptr) {
				for (int i=0; i<50; i++) {
					if (this->hashTable[hashIndex][i] != nullptr) {
						if (this->hashTable[hashIndex][i]->ID == key) {
							result = this->hashTable[hashIndex][i];
							break;
						}//if
						else {}
					}//if
					else {}
				}//for
			}//if
			else {}
		}//if
		else {}
	}//else
	return result;
}//Find

int Hash::CollisionCount(void) {
	int numberOfCollisions = 0;
	for (int i=0; i<500; i++) {
		for (int j=1; j<50; j++) {
			if (this->hashTable[i][j] != nullptr) {
				numberOfCollisions++;
			}//if
			else {}
		}//for
	}//for
	return numberOfCollisions;
}//CollisionCount

void Hash::PrintCollisionCount(void) {
	cout << endl << "The total amount of collisions using the PrintCollisionCount function is " << this->CollisionCount() << " collisions." << endl << endl;
}//PrintCollisionCount

Hash::~Hash() {
	// TODO Auto-generated destructor stub
	for (int i=0; i<500; i++) {
		for (int j=0; j<50; j++) {
			if (this->hashTable[i][j] != nullptr) {
				delete this->hashTable[i][j];
			}//if
			else {}
		}//for
		delete [] this->hashTable[i];
	}//for
	delete [] this->hashTable;
}//destructor

