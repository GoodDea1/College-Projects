/*
 * Employee.hpp
 *
 *  Created on: Nov 2, 2021
 *      Author: Nicholas Deal
 */

#ifndef EMPLOYEE_HPP_
#define EMPLOYEE_HPP_

#include <string>
using namespace std;

class Employee {
public:
	Employee();
	string ID;
	string lastName;
	string firstName;
	double salary;
	virtual ~Employee();
};

#endif /* EMPLOYEE_HPP_ */
