/*
 * Hash.hpp
 *
 *  Created on: Nov 2, 2021
 *      Author: Nicholas Deal
 */

#ifndef HASH_HPP_
#define HASH_HPP_

#include <iostream>
#include "Employee.hpp"
using namespace std;

class Hash {
private:
	Employee*** hashTable;
public:
	Hash();
	bool Insert(string, Employee*);
	Employee* Find(string);
	int CollisionCount(void);
	void PrintCollisionCount(void);
	virtual ~Hash();
};

#endif /* HASH_HPP_ */
