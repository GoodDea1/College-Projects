/*
 * Employee.cpp
 *
 *  Created on: Nov 2, 2021
 *      Author: Nicholas Deal
 */

#include "Employee.hpp"

Employee::Employee() {
	// TODO Auto-generated constructor stub
	this->salary = 0;
}

Employee::~Employee() {
	// TODO Auto-generated destructor stub
}

