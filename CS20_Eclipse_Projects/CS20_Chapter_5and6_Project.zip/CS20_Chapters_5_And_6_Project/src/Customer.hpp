/*
 * Customer.hpp
 *
 *  Created on: Oct 12, 2021
 *      Author: Nicholas Deal
 */

#ifndef CUSTOMER_HPP_
#define CUSTOMER_HPP_

#include <iostream>
using namespace std;

class Customer {
private:
	int ID;
	string Name;
	string Address;
	string City;
	string State;
	int ZipCode;
	float AccountBalance;
public:
	Customer();
	virtual ~Customer();
	float getAccountBalance() const;
	void setAccountBalance(float accountBalance);
	const string& getAddress() const;
	void setAddress(const string &address);
	const string& getCity() const;
	void setCity(const string &city);
	int getId() const;
	bool setId(int id);
	const string& getName() const;
	void setName(const string &name);
	const string& getState() const;
	void setState(const string &state);
	int getZipCode() const;
	bool setZipCode(int zipCode);
};

#endif /* CUSTOMER_HPP_ */
