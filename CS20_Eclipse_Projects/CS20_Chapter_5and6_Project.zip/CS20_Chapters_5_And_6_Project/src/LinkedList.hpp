/*
 * LinkedList.hpp
 *
 *  Created on: Oct 12, 2021
 *      Author: Nicholas Deal
 */

#ifndef LINKEDLIST_HPP_
#define LINKEDLIST_HPP_
#include "Customer.hpp"

struct node {
	Customer* data;
	node* next;
};

class LinkedList {
private:
	node* first;
	void push_back(node*, node*);
	void delete_list(node*);
	Customer* pop_back(node*);
public:
	LinkedList();
	virtual ~LinkedList();
	void push_back(Customer*);
	void push_front(Customer*);
	int size(void);
	void delete_list(void);
	void print_list(void);
	Customer* pop_front(void);
	Customer* pop_back(void);
	Customer* find(int ID);
	bool exists(int ID);
	bool deleteIt(int ID);

};

#endif /* LINKEDLIST_HPP_ */
