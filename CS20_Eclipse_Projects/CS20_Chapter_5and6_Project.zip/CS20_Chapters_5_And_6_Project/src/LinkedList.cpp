/*
 * LinkedList.cpp
 *
 *  Created on: Oct 12, 2021
 *      Author: Nicholas Deal
 */

#include "LinkedList.hpp"

//Default constructor.
//Post Condition: initializes first to nullptr.
LinkedList::LinkedList() {
	// TODO Auto-generated constructor stub
	first = nullptr;
}//LinkedList Constructor

//Wrapper function that inserts newNode if the list is empty, inserts newNode after first if, or calls the recursive version of this function.
//Pre Condition: A Customer object must be passed to the function.
//Post Condition: Creates newNode, adds customer to newNode's data, and inserts the new node at the end of the list if the list is empty.
//					Otherwise, call the recursive push_back function.
void LinkedList::push_back(Customer* customer) {
	node* newNode;
	newNode = new node();
	newNode->data = customer;
	newNode->next = nullptr;
	if (first == nullptr) {
		first = newNode;
		return;
	}//if
	else if (first->next == nullptr) {
		first->next = newNode;
		return;
	}//else if
	else {
		node* current = first;
		push_back(current->next, newNode);
	}//else

}//push_back wrapper function

//Recursive function that inserts newNode at the end of the list.
//Pre Condiction: two node pointers need to be passed, one to traverse the list, and one to insert newNode.
//Post Condition: checks to see if current->next equals to nullptr. If it does, it inserts newNode at current->next.
//					Otherwise it will call itself and traverse the next node.
void LinkedList::push_back(node* current, node* newNode) {
	if (current->next == nullptr) {
		current->next = newNode;
		return;
	}//if
	else {
		push_back(current->next, newNode);
	}//else
}//push_back

//Function to insert newNode at the beginning of the list
//Pre Condition: a Customer object must must be passed to the function.
//Post Condition: inserts newNode at the front of the list
void LinkedList::push_front(Customer* customer) {
	node* newNode;
	newNode = new node();
	newNode->data = customer;
	newNode->next = nullptr;
	if (first == nullptr) {
		first = newNode;
	}//if
	else {
		newNode->next = first;
		first = newNode;
	}//else
}//push_front

//Function that outputs the size of the list
//Pre Condition: none
//Post Condition: returns total
int LinkedList::size(void) {
	int total = 0;
	node* current = first;
	while (current != nullptr) {
		total += 1;
		current = current->next;
	}//while
	return total;
}//size

//Wrapper Function that deletes all the nodes from the list
//Pre Condition: none
//Post Condition: If the list is empty, returns a message. If there's one node, deletes that node.
//					Otherwise calls a recursive function.
void LinkedList::delete_list(void) {
	if (first == nullptr) {
		cout << "The list is already deleted." << endl;
	}//if
	else if (first->next == nullptr) {
		delete first;
		first = nullptr;
	}//else if
	else {
		node* current = first;
		delete_list(current->next);
		delete current;
		current = nullptr;
		delete first;
		first = nullptr;
	}//else
}//delete_list wrapper functoin

//Recursive function that deletes all nodes from the list
//Pre Condition: none
//Post Condition: Deletes all nodes from the list.
void LinkedList::delete_list(node* current) {
	if (current->next == nullptr) {
		delete current;
		current = nullptr;
		return;
	}//if
	else {
		delete_list(current->next);
		delete current;
		current = nullptr;
	}//else
}//delete_list

//Function that prints the data from all the nodes
//Pre Condition: none
//Post Condition: Prints the name, city, address, and account balance.
void LinkedList::print_list(void) {
	node* current = first;
	while (current != nullptr) {
		cout << endl;
		cout << "Name: " << current->data->getName() << endl;
		cout << "City: " << current->data->getCity() << endl;
		cout << "Address: " << current->data->getAddress() << endl;
		cout << "Account Balance: " << current->data->getAccountBalance() << endl;
		current = current->next;
	}//while
	cout << endl;
}//print_list

//Function that deletes the first node from the list
//Pre Condition: none
//Post Condition: Deletes first node from the list. Then returns the Customer pointer that was deleted.
Customer* LinkedList::pop_front(void) {
	Customer* dataStorage = nullptr;
	if (first == nullptr) {
		cout << "The list is empty." << endl;
		return dataStorage;
	}//if
	else if (first->next == nullptr) {
		dataStorage = first->data;
		delete first;
		first = nullptr;
		return dataStorage;
		delete dataStorage;
		dataStorage = nullptr;
	}//else if
	else {
		node* temp = first;
		first = first->next;
		dataStorage = temp->data;
		delete temp;
		temp = nullptr;
		return dataStorage;
		delete dataStorage;
	}//else
}//pop_front

//Function that deletes the last node from the list
//Pre Condition: none
//Post Condition: Deletes last node from the list. Then returns the Customer pointer that was deleted.
Customer* LinkedList::pop_back(void) {
	Customer* dataStorage = nullptr;
	if (first == nullptr) {
		cout << "The list is empty." << endl;
		return dataStorage;
	}//if
	else if (first->next == nullptr) {
		dataStorage = first->data;
		delete first;
		first = nullptr;
		return dataStorage;
	}//else if
	else {
		node* current = first;
		return pop_back(current->next);
	}
}//pop_back wrapper function

//Function that deletes the last node from the list
//Pre Condition: none
//Post Condition: Deletes last node from the list. Then returns the Customer pointer that was deleted.
Customer* LinkedList::pop_back(node* current) {
	if (current->next == nullptr) {
		Customer* dataStorage = nullptr;
		dataStorage = current->data;
		delete current;
		current = nullptr;
		return dataStorage;
	}//if
	else {
		return pop_back(current->next);
	}
}//pop_back

//Function that finds the customer ID
//Pre Condition: Must pass and integer that's an ID.
//Post Condition: Returns the Customer pointer if it's found.
Customer* LinkedList::find(int ID) {
	node* current = first;
	bool found = false;
	while (current != nullptr && found == false) {
		if (current->data->getId() == ID) {
			found = true;
		}//if
		else {
			current = current->next;
		}//else
	}//while
	if (found == true) {
		return current->data;
	}//if
	else {
		cout << "***Error: the ID you were searching for wasn't found." << endl;
		return nullptr;
	}
}//find

//Function that finds the customer ID
//Pre Condition: Must pass and integer that's an ID.
//Post Condition: Returns a boolean if it's found.
bool LinkedList::exists(int ID) {
	node* current = first;
	bool found = false;
	while (current != nullptr && found == false) {
		if (current->data->getId() == ID) {
			found = true;
		}//if
		else {
			current = current->next;
		}//else
	}//while
	if (found == true) {
		return true;
	}//if
	else {
		cout << "***Error: the ID you were searching for doesn't exist." << endl;
		return false;
	}
}//exists

bool LinkedList::deleteIt(int ID) {
	node* current = first;
	node* deletePtr = nullptr;
	bool found = false;
	while (current != nullptr && found == false) {
		if (current->data->getId() == ID) {
			first = first->next;
			delete current;
			current = nullptr;
			found = true;
		}//if
		else if (current->next->data->getId() == ID) {
			deletePtr = current->next;
			current->next = deletePtr->next;
			delete deletePtr;
			deletePtr = nullptr;
			found = true;
		}//else if
		else {
			current = current->next;
		}//else
	}//while
	if (found == true) {
		return true;
	}//if
	else {
		cout << "***Error: the ID and the customer you wish to delete doesn't exist." << endl;
		return false;
	}
}//deleteIt

LinkedList::~LinkedList() {
	// TODO Auto-generated destructor stub
	delete_list();
}//LinkedList Destructor

