/*
 * Customer.cpp
 *
 *  Created on: Oct 12, 2021
 *      Author: Nicholas Deal
 */

#include "Customer.hpp"

Customer::Customer() {
	// TODO Auto-generated constructor stub
	this->ID = 0;
	this->ZipCode = 0;
	this->AccountBalance = 0.0;
}

float Customer::getAccountBalance() const {
	return AccountBalance;
}

void Customer::setAccountBalance(float accountBalance) {
	AccountBalance = accountBalance;
}

const string& Customer::getAddress() const {
	return Address;
}

void Customer::setAddress(const string &address) {
	Address = address;
}

const string& Customer::getCity() const {
	return City;
}

void Customer::setCity(const string &city) {
	City = city;
}

int Customer::getId() const {
	return ID;
}

bool Customer::setId(int id) {
	if (id >= 1 && id <= 999999) {
		ID = id;
		return true;
	}//if
	else {
		cout << "***Error: Invalid ID value. Must be in between 1 and 999999..." << endl;
		return false;
	}//else
}

const string& Customer::getName() const {
	return Name;
}

void Customer::setName(const string &name) {
	Name = name;
}

const string& Customer::getState() const {
	return State;
}

void Customer::setState(const string &state) {
	State = state;
}

int Customer::getZipCode() const {
	return ZipCode;
}

bool Customer::setZipCode(int zipCode) {
	if (zipCode >= 10000 && zipCode <= 99999) {
		ZipCode = zipCode;
		return true;
	}//if
	else {
		cout << "***Error: Invalid ZipCode value. Must be in between 10000 and 99999..." << endl;
		return false;
	}//else
}

Customer::~Customer() {
	// TODO Auto-generated destructor stub
}

