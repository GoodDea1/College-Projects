//============================================================================
// Name        : CS20_Chapters_5_And_6_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Customer.hpp"
#include "LinkedList.hpp"
using namespace std;

int main() {

	LinkedList* theList = new LinkedList;
	Customer* theCustomer = nullptr;

	theCustomer = new Customer();
	theCustomer->setName("Nick");
	theCustomer->setId(1);
	theCustomer->setCity("Dublin");
	theCustomer->setAddress("123");
	theCustomer->setAccountBalance(100);
	theList->push_back(theCustomer);

	theCustomer = new Customer();
	theCustomer->setName("Carl");
	theCustomer->setId(2);
	theCustomer->setCity("New York");
	theCustomer->setAddress("456");
	theCustomer->setAccountBalance(200);
	theList->push_front(theCustomer);

	theCustomer = new Customer();
	theCustomer->setName("Nora");
	theCustomer->setId(3);
	theCustomer->setCity("New Orleans");
	theCustomer->setAddress("789");
	theCustomer->setAccountBalance(300);
	theList->push_back(theCustomer);

	theCustomer = new Customer();
	theCustomer->setName("Jason");
	theCustomer->setId(4);
	theCustomer->setCity("London");
	theCustomer->setAddress("741");
	theCustomer->setAccountBalance(400);
	theList->push_front(theCustomer);

	theCustomer = new Customer();
	theCustomer->setName("Musubi");
	theCustomer->setId(5);
	theCustomer->setCity("Osaka");
	theCustomer->setAddress("852");
	theCustomer->setAccountBalance(500);
	theList->push_back(theCustomer);

	theCustomer = new Customer();
	theCustomer->setName("Simon");
	theCustomer->setId(6);
	theCustomer->setCity("Jerusalem");
	theCustomer->setAddress("963");
	theCustomer->setAccountBalance(600);
	theList->push_front(theCustomer);

	cout << "Outputting list size..." << endl;
	cout << theList->size() << endl;

//	cout << endl << "Finding customer..." << endl;
//	if (theList->exists(3)) {
//		cout << "Customer found!" << endl;
//	}//if
//	else {
//		cout << "Customer not found..." << endl;
//	}//else
//
//	cout << endl << "Executing deleteIt function..." << endl;
//	theList->deleteIt(3);
//
//	cout << endl << "Finding customer..." << endl;
//	if (theList->exists(3)) {
//		cout << "Customer found!" << endl;
//	}//if
//	else {
//		cout << "Customer not found..." << endl;
//	}//else
//
//	cout << endl << "Printing the list..." << endl;
//	theList->print_list();

	cout << endl << "Executing pop_front..." << endl;
	theList->pop_front();
	cout << "Executing pop_back..." << endl;
	theList->pop_back();

	cout << endl << "Printing the list..." << endl;
	theList->print_list();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
