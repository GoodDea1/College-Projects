/*
 * Stack.hpp
 *
 *  Created on: Oct 19, 2021
 *      Author: Nicholas Deal
 */

#ifndef STACK_HPP_
#define STACK_HPP_

#include <LinkedList.hpp>
#include <cstring>
#include <iostream>
using namespace std;

class Stack: protected LinkedList {
private:
	int maxSize;
public:
	Stack();
	Stack(int);
	void push(Customer*);
	void pop(void);
	Customer* top(void);
	bool isEmptyStack(void);
	bool isFullStack(void);
	virtual ~Stack();
};

#endif /* STACK_HPP_ */
