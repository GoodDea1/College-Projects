/*
 * Queue.cpp
 *
 *  Created on: Oct 19, 2021
 *      Author: Nicholas Deal
 */

#include "Queue.hpp"

Queue::Queue() {
	// TODO Auto-generated constructor stub
	this->maxSize = 100;
}//Queue default constructor

Queue::Queue(int x) {
	if (x <= 0) {
		char cStringException[] = "Invalid Size";
		throw cStringException;
	}//if
	else {
		this->maxSize = x;
	}//else
}//Queue constructor

void Queue::enqueue(Customer* theCustomer) {
	if (this->size() != this->maxSize) {
		this->push_back(theCustomer);
	}//if
	else {
		char cStringException[] = "enqueue error";
		throw cStringException;
	}//else
}//enqueue

void Queue::dequeue(void) {
	if (this->size() != 0) {
		this->pop_front();
	}//if
	else {
		char cStringException[] = "dequeue error";
		throw cStringException;
	}//else
}//dequeue

Customer* Queue::front(void) {
	if (this->size() != 0) {
		return LinkedList::front();
	}//if
	else {
		cout << "The queue is empty." << endl;
		return nullptr;
	}//else
}//front

bool Queue::isEmptyQueue(void) {
	if (this->size() == 0) {
		return true;
	}//if
	else {
		return false;
	}//else
}//isEmptyQueue

bool Queue::isFullQueue(void) {
	if (this->size() == this->maxSize) {
		return true;
	}//if
	else {
		return false;
	}//else
}//isFullQueue

Queue::~Queue() {
	// TODO Auto-generated destructor stub
}//Queue destructor

