//============================================================================
// Name        : CS20_Chapters_7_And_8_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstring>
#include <Customer.hpp>
#include "Stack.hpp"
#include "Queue.hpp"
using namespace std;

int main() {

	Stack* myStack = new Stack();
	Queue* myQueue = new Queue();
	Customer* theCustomer;

	try {
		for (int i=0; i<=100; i++) {
			theCustomer = new Customer();
			theCustomer->setID(i+1);
			myStack->push(theCustomer);
		}//for
	}//try
	catch (char* cString) {
			cout << "push error" << endl;
	}//catch

	if (myStack->isFullStack()) {
		cout << "The stack is full." << endl;
	}//if
	else {
		cout << "The stack is not full." << endl;
	}//else

	cout << "The top of the stack returns " << myStack->top()->getID() << endl;

	try {
		for (int i=0; i<=100; i++) {
			myStack->pop();
		}//for
	}//try
	catch (char* cString) {
		cout << "pop error" << endl;
	}//catch

	if (myStack->isEmptyStack()) {
		cout << "The stack is empty." << endl;
	}//if
	else {
		cout << "The stack is not empty." << endl;
	}//else

	try {
		for (int i=0; i<=100; i++) {
			theCustomer = new Customer();
			theCustomer->setID(i+1);
			myQueue->enqueue(theCustomer);
		}//for
	}//try
	catch (char* cString) {
			cout << "enqueue error" << endl;
	}//catch

	if (myQueue->isFullQueue()) {
		cout << "The queue is full." << endl;
	}//if
	else {
		cout << "The queue is not full." << endl;
	}//else

	//myQueue->dequeue();
	cout << "The front of the queue returns " << myQueue->front()->getID() << endl;

	try {
		for (int i=0; i<=100; i++) {
			myQueue->dequeue();
		}//for
	}//try
	catch (char* cString) {
		cout << "dequeue error" << endl;
	}//catch

	if (myQueue->isEmptyQueue()) {
		cout << "The queue is empty." << endl;
	}//if
	else {
		cout << "The queue is not empty." << endl;
	}//else

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
