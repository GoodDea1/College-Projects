/*
 * Queue.hpp
 *
 *  Created on: Oct 19, 2021
 *      Author: Nicholas Deal
 */

#ifndef QUEUE_HPP_
#define QUEUE_HPP_

#include <LinkedList.hpp>
#include <cstring>
#include <iostream>
using namespace std;

class Queue: protected LinkedList {
private:
	int maxSize;
public:
	Queue();
	Queue(int);
	void enqueue(Customer*);
	void dequeue(void);
	Customer* front(void);
	bool isEmptyQueue(void);
	bool isFullQueue(void);
	virtual ~Queue();
};

#endif /* QUEUE_HPP_ */
