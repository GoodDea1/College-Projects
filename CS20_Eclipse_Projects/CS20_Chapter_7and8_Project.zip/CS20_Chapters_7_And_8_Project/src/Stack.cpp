/*
 * Stack.cpp
 *
 *  Created on: Oct 19, 2021
 *      Author: Nicholas Deal
 */

#include "Stack.hpp"

Stack::Stack() {
	// TODO Auto-generated constructor stub
	this->maxSize = 100;
}//Stack default constructor

Stack::Stack(int x) {
	if (x <= 0) {
		char cStringException[] = "Invalid Size";
		throw cStringException;
	}//if
	else {
		this->maxSize = x;
	}//else
}//Stack constructor

void Stack::push(Customer* theCustomer) {
	if (this->size() != this->maxSize) {
		this->push_back(theCustomer);
	}//if
	else {
		char cStringException[] = "push error";
		throw cStringException;
	}//else
}//push

void Stack::pop(void) {
	if (this->size() != 0) {
		this->pop_back();
	}//if
	else {
		char cStringException[] = "pop error";
		throw cStringException;
	}//else
}//pop

Customer* Stack::top(void) {
	if (this->size() != 0) {
		return this->back();
	}//if
	else {
		cout << "The stack is empty." << endl;
		return nullptr;
	}//else
}//top

bool Stack::isEmptyStack(void) {
	if (this->size() == 0) {
		return true;
	}//if
	else {
		return false;
	}//else
}//isEmptyStack

bool Stack::isFullStack(void) {
	if (this->size() == this->maxSize) {
		return true;
	}//if
	else {
		return false;
	}//else
}//isFullStack

Stack::~Stack() {
	// TODO Auto-generated destructor stub
}//Stack destructor

