//============================================================================
// Name        : CS20_Eclipse_Test_Upload.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "My name is Nicholas Deal." << endl;
	cout << "Welcome to my program!" << endl;
	cout << "My favorite entertainment program is Cartoon Network and birds are my favorite pets." << endl;
	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
