/*
 * Planet.hpp
 *
 *  Created on: Sep 7, 2021
 *      Author: Nicholas Deal
 */

#ifndef PLANET_HPP_
#define PLANET_HPP_

#include <iostream>
using namespace std;

class Planet {
private:
	string Name;
	double Mass = 0;
	int OrbitalDistance = 0;
public:
	Planet();
	virtual ~Planet();
	double getMass() const;
	bool setMass(double mass);
	const string& getName() const;
	bool setName(const string &name);
	int getOrbitalDistance() const;
	bool setOrbitalDistance(int orbitalDistance);
};

#endif /* PLANET_HPP_ */
