//============================================================================
// Name        : CS20_OOP_Pointer_Planets.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <ctime>
#include "Planet.hpp"
#include "ArrayVector.hpp"
using namespace std;

int main() {

	ArrayVector theArray;
	Planet* aPlanet = nullptr;
	srand(time(0));
	int totalTests = rand()%1000;

	cout << "Starting size of the list is: " << theArray.size() << endl;
	cout << "Starting size of the array is: " << theArray.getCurrentArraySize() << endl;

	for (int i=0; i<totalTests; i++) {
		aPlanet = new Planet();
		aPlanet->setMass(10 * i);
		aPlanet->setName("Test");
		aPlanet->setOrbitalDistance(i);
		theArray.pushback(aPlanet);
	}//for

	cout << "Size of the list after pushback is: " << theArray.size() << endl;
	cout << "Size of the array after pushback is: " << theArray.getCurrentArraySize() << endl;
	for (int i=0; i<totalTests; i++) {
		aPlanet = theArray.popback();
		delete aPlanet;
	}//for

	cout << "Size of the list after popback is: " << theArray.size() << endl;
	cout << "Size of the array after popback is: " << theArray.getCurrentArraySize() << endl;

	theArray.clear();

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
