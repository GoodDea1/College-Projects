/*
 * Planet.cpp
 *
 *  Created on: Sep 7, 2021
 *      Author: Nicholas Deal
 */

#include "Planet.hpp"

Planet::Planet() {
	// TODO Auto-generated constructor stub

}

double Planet::getMass() const {
	return Mass;
}

bool Planet::setMass(double mass) {
	if (mass <= 0) {
		return false;
	}//if
	else {
		Mass = mass;
		return true;
	}//else
}

const string& Planet::getName() const {
	return Name;
}

bool Planet::setName(const string &name) {
	if (name == "") {
		return false;
	}//if
	else {
		Name = name;
		return true;
	}//else
}

int Planet::getOrbitalDistance() const {
	return OrbitalDistance;
}

bool Planet::setOrbitalDistance(int orbitalDistance) {
	if (orbitalDistance <= 0) {
		return false;
	}//if
	else {
		OrbitalDistance = orbitalDistance;
		return true;
	}//else
}

Planet::~Planet() {
	// TODO Auto-generated destructor stub
}

