/*
 * ArrayVector.cpp
 *
 *  Created on: Sep 7, 2021
 *      Author: Nicholas Deal
 */

#include "ArrayVector.hpp"

ArrayVector::ArrayVector() {
	// TODO Auto-generated constructor stub
	this->defaultPlanetPtrArray = new Planet*[5];
	for (int i = 0; i < 5; i++) {
		defaultPlanetPtrArray[i] = nullptr;
	}//for
	this->currentArraySize = 5;
	this->lastItemInArray = 0;
}

int ArrayVector::getCurrentArraySize() const {
	return currentArraySize;
}

void ArrayVector::setCurrentArraySize(int currentArraySize) {
	this->currentArraySize = currentArraySize;
}

int ArrayVector::getLastItemInArray() const {
	return lastItemInArray;
}

void ArrayVector::setLastItemInArray(int lastItemInArray) {
	this->lastItemInArray = lastItemInArray;
}

int ArrayVector::size() {
	return getLastItemInArray();
}

bool ArrayVector::pushback(Planet* planetPtr) {
	defaultPlanetPtrArray[getLastItemInArray()] = planetPtr;
	if ((getLastItemInArray()+1) == getCurrentArraySize()) {
		try {
			setCurrentArraySize(getCurrentArraySize()+5);
			Planet** temp = new Planet*[getCurrentArraySize()];
			for (int i=0; i<getCurrentArraySize(); i++) {
				if (i > getLastItemInArray()) {
					temp[i] = nullptr;
				}//if
				else {
					temp[i] = defaultPlanetPtrArray[i];
				}//else
			}//for
			delete [] defaultPlanetPtrArray;
			defaultPlanetPtrArray = temp;
			temp = nullptr;
		}//try
		catch (const std::bad_alloc &e) {
			cout << "*** A memory exhaustion issue occurred during pushback" << endl;
			return false;
		}//catch
	}//if
	else {}
	setLastItemInArray(getLastItemInArray()+1);
	return true;
}

Planet* ArrayVector::popback() {
	if (defaultPlanetPtrArray[getLastItemInArray()-1] == nullptr) {
		return nullptr;
	}//if
	else {
		Planet* returnPtr = defaultPlanetPtrArray[getLastItemInArray()-1];
		defaultPlanetPtrArray[getLastItemInArray()-1] = nullptr;
		if ((getCurrentArraySize()-(getLastItemInArray()+1)) >= 5) {
			if (getLastItemInArray() != 0) {
				try {
					setCurrentArraySize(getCurrentArraySize()-5);
					Planet** temp = new Planet*[getCurrentArraySize()];
					for (int i=0; i<getCurrentArraySize(); i++) {
						temp[i] = defaultPlanetPtrArray[i];
					}//for
					delete [] defaultPlanetPtrArray;
					defaultPlanetPtrArray = temp;
					temp = nullptr;
				}//try
				catch (const std::bad_alloc &e) {
					cout << "*** A memory exhaustion issue occurred during popback" << endl;
				}//catch
			}//if
			else {}
		}//if
		else {}
		setLastItemInArray(getLastItemInArray()-1);
		return returnPtr;
	}//else
}

void ArrayVector::clear() {
	for (int i = 0; i < getCurrentArraySize(); i++) {
		delete defaultPlanetPtrArray[i];
		defaultPlanetPtrArray[i] = nullptr;
	}//for
	if (getCurrentArraySize() > 5) {
		setCurrentArraySize(5);
		Planet** temp = new Planet*[getCurrentArraySize()];
		delete [] defaultPlanetPtrArray;
		defaultPlanetPtrArray = temp;
		temp = nullptr;
	}//if
	else {}
}

ArrayVector::~ArrayVector() {
	// TODO Auto-generated destructor stub
	delete this->defaultPlanetPtrArray;
}

