/*
 * ArrayVector.hpp
 *
 *  Created on: Sep 7, 2021
 *      Author: Nicholas Deal
 */

#ifndef ARRAYVECTOR_HPP_
#define ARRAYVECTOR_HPP_

#include "Planet.hpp"

class ArrayVector {
private:
	int currentArraySize;
	int lastItemInArray;
	Planet** defaultPlanetPtrArray;
public:
	ArrayVector();
	virtual ~ArrayVector();
	int getCurrentArraySize() const;
	void setCurrentArraySize(int currentArraySize);
	int getLastItemInArray() const;
	void setLastItemInArray(int lastItemInArray);
	int size();
	bool pushback(Planet* planetPtr);
	Planet* popback();
	void clear();
};

#endif /* ARRAYVECTOR_HPP_ */
