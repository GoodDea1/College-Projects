/*
 * Customer.cpp
 *
 *  Created on: Sep 30, 2021
 *      Author: Nicholas Deal
 */

#include "Customer.hpp"

Customer::Customer() {
	// TODO Auto-generated constructor stub
	this->ID = 0;
}

const string& Customer::getEmail() const {
	return email;
}

void Customer::setEmail(const string &email) {
	this->email = email;
}

const string& Customer::getFirstName() const {
	return firstName;
}

void Customer::setFirstName(const string &firstName) {
	this->firstName = firstName;
}

int Customer::getId() const {
	return ID;
}

void Customer::setId(int id) {
	ID = id;
}

const string& Customer::getLastName() const {
	return lastName;
}

void Customer::setLastName(const string &lastName) {
	this->lastName = lastName;
}

Customer::~Customer() {
	// TODO Auto-generated destructor stub
}

