/*
 * Order.cpp
 *
 *  Created on: Sep 30, 2021
 *      Author: Nicholas Deal
 */

#include "Order.hpp"

Order::Order() {
	// TODO Auto-generated constructor stub
	this->customerID = 0;
	this->itemPrice = 0.0;
}

int Order::getCustomerId() const {
	return customerID;
}

void Order::setCustomerId(int customerId) {
	customerID = customerId;
}

const string& Order::getItemDescription() const {
	return itemDescription;
}

void Order::setItemDescription(const string &itemDescription) {
	this->itemDescription = itemDescription;
}

const string& Order::getItemId() const {
	return itemID;
}

void Order::setItemId(const string &itemId) {
	itemID = itemId;
}

float Order::getItemPrice() const {
	return itemPrice;
}

void Order::setItemPrice(float itemPrice) {
	this->itemPrice = itemPrice;
}

Order::~Order() {
	// TODO Auto-generated destructor stub
}

