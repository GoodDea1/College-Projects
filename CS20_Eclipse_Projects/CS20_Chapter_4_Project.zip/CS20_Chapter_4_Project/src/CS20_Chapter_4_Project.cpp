//============================================================================
// Name        : CS20_Chapter_4_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <map>
#include <iterator>
#include <iomanip>
#include "Customer.hpp"
#include "Order.hpp"
using namespace std;

int main() {

	ifstream inputFile;
	map<int, Customer*> customerMap;
	map<int, Customer*>::iterator customerMapIT;
	pair<map<int, Customer*>::iterator, bool> mapInsert;
	multimap<int, Order*> orderMultiMap;
	multimap<int, Order*>::iterator orderMultiMapIT;
	pair<multimap<int, Order*>::iterator,
		 multimap<int, Order*>::iterator> range;
	int inputID = 0;
	string inputFirstName;
	string inputLastName;
	string inputEmail;
	int inputCustomerID = 0;
	string inputItemID;
	string inputItemDescription;
	float inputItemPrice = 0.0;
	Customer* aCustomer;
	Order* anOrder;
	char userInput;
	int userInput2 = 0;
	float totalPrice = 0.0;
	unsigned int count = 0;

	//Reading customer file into map
	cout << "Reading Customers.txt file into customer map..." << endl;
	inputFile.open("Customers.txt");
	if (inputFile.fail()) {
		cout << "*** Something wrong happened when opening the customers file" << endl;
	}//if
	else {
		while (!inputFile.eof()) {
			aCustomer = new Customer();
			inputFile >> inputID;
			aCustomer->setId(inputID);
			inputFile >> inputLastName;
			aCustomer->setLastName(inputLastName);
			inputFile >> inputFirstName;
			aCustomer->setFirstName(inputFirstName);
			inputFile >> inputEmail;
			aCustomer->setEmail(inputEmail);
			mapInsert = customerMap.insert(pair<int, Customer*>(aCustomer->getId(), aCustomer));
		}//while
	}//else
	inputFile.close();

	//Reading order items file into multimap
	cout << "Reading Orderitems.txt file into order multimap..." << endl;
	inputFile.open("Orderitems.txt");
	if (inputFile.fail()) {
		cout << "*** Something wrong happened when opening the order items file" << endl;
	}//if
	else {
		while (!inputFile.eof()) {
			anOrder = new Order();
			inputFile >> inputCustomerID;
			anOrder->setCustomerId(inputCustomerID);
			inputFile >> inputItemID;
			anOrder->setItemId(inputItemID);
			inputFile >> inputItemDescription;
			anOrder->setItemDescription(inputItemDescription);
			inputFile >> inputItemPrice;
			anOrder->setItemPrice(inputItemPrice);
			orderMultiMap.insert(pair<int, Order*>(anOrder->getCustomerId(), anOrder));
		}//while
	}//else
	inputFile.close();

	do {
		cout << endl;
		cout << "    Item Order Menu" << endl;
		cout << "============================" << endl;
		cout << endl;
		cout << "1. Print All Customers" << endl;
		cout << "2. Search and Print All Customer Items" << endl;
		cout << "x. Exit the Program" << endl;
		cout << endl;
		cout << "============================" << endl;
		cout << "Please enter one of the options: ";
		cin >> userInput;
		switch (userInput) {
			case '1':
				cout << endl;
				cout << "    Customer Report" << endl;
				cout << "============================" << endl;
				cout << endl;
				cout << left;
				cout << setw(6) << "ID" << setw(14) << "Last Name" << setw(16) << "First Name" << setw(20) << "Email" << endl;
				cout << setw(6) << "--" << setw(14) << "---------" << setw(16) << "----------" << setw(20) << "-----" << endl;
				for (customerMapIT = customerMap.begin(); customerMapIT != customerMap.end(); ++customerMapIT) {
					cout << setw(6) << (*customerMapIT).second->getId() << setw(14) << (*customerMapIT).second->getLastName() << setw(16) <<
							(*customerMapIT).second->getFirstName() << setw(20) << (*customerMapIT).second->getEmail() << endl;

				}//for
				cout << endl;
				cout << "============================" << endl;
				break;
			case '2':
				cout << "Please enter the customer ID you want to search: ";
				cin >> userInput2;
				cout << "...Searching..." << endl;
				count = orderMultiMap.count(userInput2);
				if (count == 0) {
					cout << "***Error: the customer ID entered doesn't exist..." << endl;
				}//if
				else {
					range = orderMultiMap.equal_range(userInput2);
					cout << endl;
					cout << "    Order Items Report" << endl;
					cout << "============================" << endl;
					cout << endl;
					cout << setw(15) << "Customer ID" << setw(14) << "Item ID" << setw(18) << "Description" << setw(15) << "Price" << endl;
					cout << setw(15) << "-----------" << setw(14) << "-------" << setw(18) << "-----------" << setw(15) << "-----" << endl;
					for (orderMultiMapIT = range.first; orderMultiMapIT != range.second; ++orderMultiMapIT) {
						cout << setw(15) << (*orderMultiMapIT).second->getCustomerId() << setw(14) << (*orderMultiMapIT).second->getItemId() << setw(18) <<
								(*orderMultiMapIT).second->getItemDescription() << setw(15) << (*orderMultiMapIT).second->getItemPrice() << endl;
						totalPrice += (*orderMultiMapIT).second->getItemPrice();
					}//for
					cout << endl;
					cout << "============================" << endl;
					cout << "Total Price: " << totalPrice << endl;
					totalPrice = 0;
				}//else
				break;
			case 'x':
				break;
			default:
				cout << "***Error: Invalid input, please enter a valid option" << endl;
				break;
		}//switch
	} while(userInput != 'x');
	//do-while loop

	for (customerMapIT = customerMap.begin(); customerMapIT != customerMap.end(); ++customerMapIT) {
		delete (*customerMapIT).second;
	}//for
	customerMap.clear();

	for (orderMultiMapIT = orderMultiMap.begin(); orderMultiMapIT != orderMultiMap.end(); ++orderMultiMapIT) {
		delete (*orderMultiMapIT).second;
	}//for
	orderMultiMap.clear();

	cout << "Program ending, have a nice day!" << endl; // prints Program ending, have a nice day!
	return 0;
}
