/*
 * Customer.hpp
 *
 *  Created on: Sep 30, 2021
 *      Author: Nicholas Deal
 */

#ifndef CUSTOMER_HPP_
#define CUSTOMER_HPP_

#include <string>
using namespace std;

class Customer {
private:
	int ID;
	string firstName;
	string lastName;
	string email;
public:
	Customer();
	virtual ~Customer();
	const string& getEmail() const;
	void setEmail(const string &email);
	const string& getFirstName() const;
	void setFirstName(const string &firstName);
	int getId() const;
	void setId(int id);
	const string& getLastName() const;
	void setLastName(const string &lastName);
};

#endif /* CUSTOMER_HPP_ */
