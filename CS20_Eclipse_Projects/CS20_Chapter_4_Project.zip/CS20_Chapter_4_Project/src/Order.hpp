/*
 * Order.hpp
 *
 *  Created on: Sep 30, 2021
 *      Author: Nicholas Deal
 */

#ifndef ORDER_HPP_
#define ORDER_HPP_

#include <string>
using namespace std;

class Order {
private:
	int customerID;
	string itemID;
	string itemDescription;
	float itemPrice;
public:
	Order();
	virtual ~Order();
	int getCustomerId() const;
	void setCustomerId(int customerId);
	const string& getItemDescription() const;
	void setItemDescription(const string &itemDescription);
	const string& getItemId() const;
	void setItemId(const string &itemId);
	float getItemPrice() const;
	void setItemPrice(float itemPrice);
};

#endif /* ORDER_HPP_ */
