/*
 * Planet.cpp
 *
 *  Created on: Nov 11, 2021
 *      Author: Nicholas Deal
 */

#include "Planet.hpp"

Planet::Planet() {
	// TODO Auto-generated constructor stub
	this->first = 0;
}//Constructor

Planet::~Planet() {
	// TODO Auto-generated destructor stub
}//Destructor

