/*
 * Planet.hpp
 *
 *  Created on: Nov 11, 2021
 *      Author: Nicholas Deal
 */

#ifndef PLANET_HPP_
#define PLANET_HPP_

#include <string>
using namespace std;

class Planet {
public:
	Planet();
	int first;
	string Name;
	string URL;
	virtual ~Planet();
};

#endif /* PLANET_HPP_ */
