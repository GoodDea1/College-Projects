/*
 * Heap.hpp
 *
 *  Created on: Nov 11, 2021
 *      Author: Nicholas Deal
 */

#ifndef HEAP_HPP_
#define HEAP_HPP_

#include <iostream>
#include <vector>
#include "Planet.hpp"
using namespace std;

struct HeapNode {
	int key = 0;
	Planet* data;
};

class Heap {
private:
	void upHeap(void);
	void downHeap(void);
	vector<HeapNode> theHeap;
	int heapType;
public:
	Heap();
	void push(int, Planet*);
	Planet* top(void);
	void pop(void);
	void setType(int);
	virtual ~Heap();
	int size(void);
};

#endif /* HEAP_HPP_ */
