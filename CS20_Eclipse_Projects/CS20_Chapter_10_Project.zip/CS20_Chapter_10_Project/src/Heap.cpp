/*
 * Heap.cpp
 *
 *  Created on: Nov 11, 2021
 *      Author: Nicholas Deal
 */

#include "Heap.hpp"

Heap::Heap() {
	// TODO Auto-generated constructor stub
	this->heapType = 1;
}//Constructor

void Heap::upHeap(void) {
	//maxHeap
	if (this->heapType == 1) {
		HeapNode temp;
		int keyIndex = (this->size()-1);
		while (keyIndex != 0) {
			if ((((keyIndex)-1)/2) != 0) {
				if (this->theHeap[keyIndex].key > this->theHeap[((keyIndex)-1)/2].key) {
					temp = this->theHeap[((keyIndex)-1)/2];
					this->theHeap[((keyIndex)-1)/2] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = (((keyIndex)-1)/2);
				}//if
				else {
					break;
				}//else
			}//if
			else {
				break;
			}//else
		}//while
	}//if
	//minHeap
	else if (this->heapType == 0) {
		HeapNode temp;
		int keyIndex = (this->size()-1);
		while (keyIndex != 0) {
			if ((((keyIndex)-1)/2) != 0) {
				if (this->theHeap[keyIndex].key < this->theHeap[((keyIndex)-1)/2].key) {
					temp = this->theHeap[((keyIndex)-1)/2];
					this->theHeap[((keyIndex)-1)/2] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = (((keyIndex)-1)/2);
				}//if
				else {
					break;
				}//else
			}//if
			else {
				break;
			}//else
		}//while
	}//else if
	else {}
}//upHeap

void Heap::downHeap(void) {
	//maxHeap
	if (this->heapType == 1) {
		HeapNode temp;
		int keyIndex = 0;
		while (keyIndex < (this->size()-1)) {
			if ((((2*keyIndex)+1) < (this->size()-1)) && (((2*keyIndex)+2) < (this->size()-1))) {
				if (((2*keyIndex)+1) > ((2*keyIndex)+2)) {
					temp = this->theHeap[(2*keyIndex)+1];
					this->theHeap[(2*keyIndex)+1] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = ((2*keyIndex)+1);
				}//if
				else if (((2*keyIndex)+1) < ((2*keyIndex)+2)) {
					temp = this->theHeap[(2*keyIndex)+2];
					this->theHeap[(2*keyIndex)+2] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = ((2*keyIndex)+2);
				}//else if
				else {
					break;
				}//else
			}//if
			else {
				break;
			}//else
		}//while
	}//if
	//minHeap
	else if (this->heapType == 0) {
		HeapNode temp;
		int keyIndex = 0;
		while (keyIndex <= (this->size()-1)) {
			if ((((2*keyIndex)+1) < (this->size()-1)) && (((2*keyIndex)+2) < (this->size()-1))) {
				if (((2*keyIndex)+1) < ((2*keyIndex)+2)) {
					temp = this->theHeap[(2*keyIndex)+1];
					this->theHeap[(2*keyIndex)+1] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = ((2*keyIndex)+1);
				}//if
				else if (((2*keyIndex)+1) > ((2*keyIndex)+2)) {
					temp = this->theHeap[(2*keyIndex)+2];
					this->theHeap[(2*keyIndex)+2] = this->theHeap[keyIndex];
					this->theHeap[keyIndex] = temp;
					keyIndex = ((2*keyIndex)+2);
				}//else if
				else {
					break;
				}//else
			}//if
			else {
				break;
			}//else
		}//while
	}//else if
	else {}
}//downHeap

void Heap::push(int key, Planet* newPlanet) {
	HeapNode newNode;
	newNode.key = key;
	newNode.data = newPlanet;
	this->theHeap.push_back(newNode);
	this->upHeap();
}//push

Planet* Heap::top(void) {
	return this->theHeap[0].data;
}//top

void Heap::pop(void) {
	if (this->size() == 0) {
		cout << "The heap is empty" << endl;
	}//if
	else {
		this->theHeap[0] = this->theHeap[this->size()-1];
//		delete this->theHeap[this->size()-1].data;
//		this->theHeap[this->size()-1].data = nullptr;
//		this->theHeap[this->size()-1].key = 0;
		this->theHeap.pop_back();
		this->downHeap();
	}//else
}//pop

void Heap::setType(int type) {
	if (this->size() != 0) {
		char* charPtr = new char('e');
		throw charPtr;
	}//if
	else {
		this->heapType = type;
	}//else
}//setType

int Heap::size(void) {
	return this->theHeap.vector::size();
}//size

Heap::~Heap() {
	// TODO Auto-generated destructor stub
	while (this->size() != 0) {
		delete this->theHeap[this->size()-1].data;
		this->theHeap.pop_back();
	}//while
}//Destructor

