//============================================================================
// Name        : CS20_Chapter_10_Project.cpp
// Author      : Nicholas Deal
// Version     :
// Copyright   : Make sure you bring the money if you want to use this
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "utilities.hpp"
#include "Heap.hpp"
#include "Planet.hpp"
using namespace std;

int main() {

    Heap theHeap;
    Planet* newPlanet;

    theHeap.setType(0);				//Min Heap

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Mercury";
    newPlanet->URL = "https://upload.wikimedia.org/wikipedia/commons/4/4a/Mercury_in_true_color.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Venus";
    newPlanet->URL = "http://www.nasa.gov/sites/default/files/thumbnails/image/imagesvenus20191211venus20191211-16.jpeg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Earth";
    newPlanet->URL = "https://cdn.mos.cms.futurecdn.net/3upZx2gxxLpW7MBbnKYQLH-1200-80.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Mars";
    newPlanet->URL = "https://mars.nasa.gov/system/content_pages/main_images/418_marsglobe.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Jupiter";
    newPlanet->URL = "https://noirlab.edu/public/media/archives/images/screen/noirlab2116b.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Saturn";
    newPlanet->URL = "https://upload.wikimedia.org/wikipedia/commons/c/c7/Saturn_during_Equinox.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Uranus";
    newPlanet->URL = "https://images.theconversation.com/files/73449/original/image-20150302-5236-19u573n.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1000&fit=clip";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Neptune";
    newPlanet->URL = "https://media.wired.com/photos/5d04042aea706e48d9bcd1bf/master/w_2560%2Cc_limit/Science-Neptune-TA-PIA01492_orig.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Pluto";
    newPlanet->URL = "https://astronomy.com/-/media/Images/Magazine%20Articles/2019/September/ASYPL0919_09.jpg";
    theHeap.push(newPlanet->first, newPlanet);

    unsigned int theSize = theHeap.size();
    for (unsigned int i=0; i<theSize; i++) {
        newPlanet = theHeap.top();
        cout << "Key: " << newPlanet->first << endl;
        cout << "Name: " << newPlanet->Name << endl;
        cout << "URL: " << newPlanet->URL << endl;
        cout << endl;
        theHeap.pop();
        delete newPlanet;
    }//for

    Heap secondHeap;

    secondHeap.setType(1);				//Max Heap

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Mercury";
    newPlanet->URL = "https://upload.wikimedia.org/wikipedia/commons/4/4a/Mercury_in_true_color.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Venus";
    newPlanet->URL = "http://www.nasa.gov/sites/default/files/thumbnails/image/imagesvenus20191211venus20191211-16.jpeg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Earth";
    newPlanet->URL = "https://cdn.mos.cms.futurecdn.net/3upZx2gxxLpW7MBbnKYQLH-1200-80.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Mars";
    newPlanet->URL = "https://mars.nasa.gov/system/content_pages/main_images/418_marsglobe.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Jupiter";
    newPlanet->URL = "https://noirlab.edu/public/media/archives/images/screen/noirlab2116b.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Saturn";
    newPlanet->URL = "https://upload.wikimedia.org/wikipedia/commons/c/c7/Saturn_during_Equinox.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Uranus";
    newPlanet->URL = "https://images.theconversation.com/files/73449/original/image-20150302-5236-19u573n.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1000&fit=clip";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Neptune";
    newPlanet->URL = "https://media.wired.com/photos/5d04042aea706e48d9bcd1bf/master/w_2560%2Cc_limit/Science-Neptune-TA-PIA01492_orig.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    newPlanet = new Planet();
    newPlanet->first = getRandomInt(1, 1000);
    newPlanet->Name = "Pluto";
    newPlanet->URL = "https://astronomy.com/-/media/Images/Magazine%20Articles/2019/September/ASYPL0919_09.jpg";
    secondHeap.push(newPlanet->first, newPlanet);

    int secondSize = secondHeap.size();
    for (int i=0; i<secondSize; i++) {
        cout << secondHeap.top()->first << endl;
        cout << secondHeap.top()->Name << endl;
        cout << secondHeap.top()->URL << endl;
        cout << endl;
        secondHeap.pop();
    }//for

	cout << "Program ending, have a nice day!" << endl; // prints !!!Hello World!!!
	return 0;
}
